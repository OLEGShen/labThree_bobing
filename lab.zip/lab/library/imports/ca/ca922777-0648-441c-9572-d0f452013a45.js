"use strict";
cc._RF.push(module, 'ca922d3BkhEHJVy0PRSATpF', 'numing');
// scripts/numing.js

"use strict";

window.member = {
  num: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    // ...
    // score label 的引用
    scoreDisplay: {
      "default": null,
      type: cc.Label
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    // ...
    member.num = 2;
  },
  start: function start() {},
  loseScore: function loseScore() {
    if (member.num > 2) member.num -= 1;
    this.scoreDisplay.string = member.num;
  },
  gainScore: function gainScore() {
    if (member.num < 10) member.num += 1;
    this.scoreDisplay.string = member.num;
  }
});

cc._RF.pop();