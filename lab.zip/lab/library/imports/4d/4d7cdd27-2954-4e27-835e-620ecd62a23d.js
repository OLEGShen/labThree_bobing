"use strict";
cc._RF.push(module, '4d7cd0nKVROJ4NeYg7NYqI9', 'cow');
// scripts/cow.js

"use strict";

var cow_skin = cc.Class({
  name: "cow_skin",
  properties: {
    cows: {
      "default": [],
      type: [cc.SpriteFrame]
    }
  }
});
cc.Class({
  "extends": cc.Component,
  properties: {
    cow_set: {
      "default": [],
      type: [cow_skin]
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.intervalTime = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.intervalTime += dt;
    var index = Math.floor(this.intervalTime / 0.2);
    index = index % 5; //cc.log(index);

    var cowSet = this.cow_set[0];
    var sprite = this.node.getComponent(cc.Sprite);
    sprite.spriteFrame = cowSet.cows[index];
  }
});

cc._RF.pop();