"use strict";
cc._RF.push(module, 'd9d870fp7BP3Lt7UXPXcM1F', 'toanswersss');
// scripts/toanswersss.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  to: function to() {
    cc.director.loadScene("playingtwo");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();