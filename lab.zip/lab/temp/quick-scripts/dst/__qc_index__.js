
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/count');
require('./assets/scripts/cow');
require('./assets/scripts/gotoanswer');
require('./assets/scripts/guizejs');
require('./assets/scripts/homejs');
require('./assets/scripts/numing');
require('./assets/scripts/rolltwo');
require('./assets/scripts/toanswersss');
require('./assets/scripts/tonum');
require('./assets/scripts/totouzi');
require('./assets/scripts/totouzitwo');
require('./assets/scripts/turnall');
require('./assets/scripts/turnaround');
require('./assets/scripts/turntwo');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();