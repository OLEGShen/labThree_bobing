
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/cow.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4d7cd0nKVROJ4NeYg7NYqI9', 'cow');
// scripts/cow.js

"use strict";

var cow_skin = cc.Class({
  name: "cow_skin",
  properties: {
    cows: {
      "default": [],
      type: [cc.SpriteFrame]
    }
  }
});
cc.Class({
  "extends": cc.Component,
  properties: {
    cow_set: {
      "default": [],
      type: [cow_skin]
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.intervalTime = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.intervalTime += dt;
    var index = Math.floor(this.intervalTime / 0.2);
    index = index % 5; //cc.log(index);

    var cowSet = this.cow_set[0];
    var sprite = this.node.getComponent(cc.Sprite);
    sprite.spriteFrame = cowSet.cows[index];
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY293LmpzIl0sIm5hbWVzIjpbImNvd19za2luIiwiY2MiLCJDbGFzcyIsIm5hbWUiLCJwcm9wZXJ0aWVzIiwiY293cyIsInR5cGUiLCJTcHJpdGVGcmFtZSIsIkNvbXBvbmVudCIsImNvd19zZXQiLCJvbkxvYWQiLCJpbnRlcnZhbFRpbWUiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiaW5kZXgiLCJNYXRoIiwiZmxvb3IiLCJjb3dTZXQiLCJzcHJpdGUiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBTUEsUUFBUSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUN0QkMsRUFBQUEsSUFBSSxFQUFDLFVBRGlCO0FBRXRCQyxFQUFBQSxVQUFVLEVBQUM7QUFDUEMsSUFBQUEsSUFBSSxFQUFDO0FBQ0QsaUJBQVEsRUFEUDtBQUVEQyxNQUFBQSxJQUFJLEVBQUMsQ0FBQ0wsRUFBRSxDQUFDTSxXQUFKO0FBRko7QUFERTtBQUZXLENBQVQsQ0FBakI7QUFVQU4sRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNPLFNBRFA7QUFHTEosRUFBQUEsVUFBVSxFQUFFO0FBQ1JLLElBQUFBLE9BQU8sRUFBQztBQUNKLGlCQUFRLEVBREo7QUFFSkgsTUFBQUEsSUFBSSxFQUFDLENBQUNOLFFBQUQ7QUFGRDtBQURBLEdBSFA7QUFVTDtBQUVBVSxFQUFBQSxNQVpLLG9CQVlLO0FBQ04sU0FBS0MsWUFBTCxHQUFvQixDQUFwQjtBQUNILEdBZEk7QUFnQkxDLEVBQUFBLEtBaEJLLG1CQWdCSSxDQUVSLENBbEJJO0FBcUJMQyxFQUFBQSxNQXJCSyxrQkFxQkdDLEVBckJILEVBcUJPO0FBQ1IsU0FBS0gsWUFBTCxJQUFxQkcsRUFBckI7QUFDQSxRQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXLEtBQUtOLFlBQUwsR0FBb0IsR0FBL0IsQ0FBWjtBQUVBSSxJQUFBQSxLQUFLLEdBQUdBLEtBQUssR0FBRyxDQUFoQixDQUpRLENBS1I7O0FBQ0EsUUFBSUcsTUFBTSxHQUFHLEtBQUtULE9BQUwsQ0FBYSxDQUFiLENBQWI7QUFFQSxRQUFJVSxNQUFNLEdBQUcsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjtBQUNBSCxJQUFBQSxNQUFNLENBQUNJLFdBQVAsR0FBcUJMLE1BQU0sQ0FBQ2IsSUFBUCxDQUFZVSxLQUFaLENBQXJCO0FBQ0g7QUEvQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY293X3NraW4gPSBjYy5DbGFzcyh7XHJcbiAgICBuYW1lOlwiY293X3NraW5cIixcclxuICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgIGNvd3M6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOltjYy5TcHJpdGVGcmFtZV1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBjb3dfc2V0OntcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgdHlwZTpbY293X3NraW5dXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuaW50ZXJ2YWxUaW1lID0gMDtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmludGVydmFsVGltZSArPSBkdDtcclxuICAgICAgICBsZXQgaW5kZXggPSBNYXRoLmZsb29yKHRoaXMuaW50ZXJ2YWxUaW1lIC8gMC4yKTtcclxuICAgICAgICBcclxuICAgICAgICBpbmRleCA9IGluZGV4ICUgNTtcclxuICAgICAgICAvL2NjLmxvZyhpbmRleCk7XHJcbiAgICAgICAgbGV0IGNvd1NldCA9IHRoaXMuY293X3NldFswXTtcclxuXHJcbiAgICAgICAgbGV0IHNwcml0ZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBjb3dTZXQuY293c1tpbmRleF07XHJcbiAgICB9LFxyXG59KTtcclxuIl19