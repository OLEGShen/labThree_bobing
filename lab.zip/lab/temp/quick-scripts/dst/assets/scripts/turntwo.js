
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/turntwo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b18a4tL1RhIjo25nLHNkuG7', 'turntwo');
// scripts/turntwo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    contentc: {
      type: cc.Node,
      "default": null
    },
    speed: 300
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  // onSetNum({num = 5}){
  //     //获取数字Label的个数
  //     let childCount = this.node_layout.getChildren().length;
  //     //求出单位y值
  //     let unit_y = this.node_layout.height / childCount;
  //     cc.tween(this.node_layout)
  //       .to(0.5, {position: cc.v2(this.node_layout.x, num * unit_y + unit_y / 2)}, {easing: "quadInOut"})
  //       .start();
  //   },
  start: function start() {// var level = {
    //     one: '状元插金花！',
    //     two: '六红六子', // 六子
    //     three: '五红五子', // 五子
    //     four: '普通状元',
    //     five: '对堂',
    //     six: '三红',
    //     seven: '四进',
    //     eight: '二举',
    //     nine: '一秀',
    //     ten: '没有奖哦亲~~~~~'
    // },
    // this_level; // 存储当前等级
    // this.randomNum = Math.floor(Math.random()*6) + 1;
    //this.set_value(1);
    //this.roll_tonum(3);
  },
  set_value: function set_value(value) {
    this.num_height = this.contentc.height / 12;
    this.star_y_num = this.num_height * 0.5;
    this.now_value = 0;
    this.contentc.y = this.star_y_num;
    this.randomNum = 1;

    if (value > 6 || value < 1) {
      return;
    }

    this.now_value = value;
    this.contentc.y = this.star_y_num + (this.now_value - 1) * 100;
  },
  roll_tonum: function roll_tonum(value) {
    if (value > 10 || value < 1) return;

    if (value < this.now_value) {
      var x = value; //value += 6;

      var move_s = (this.now_value - x) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.contentc.y - move_s);
      m.easing(cc.easeCubicActionInOut());
      this.contentc.runAction(m);
      this.now_value = x;
    } else {
      var move_s = (value - this.now_value) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.contentc.y + move_s);
      m.easing(cc.easeCubicActionInOut());
      this.contentc.runAction(m);
      this.now_value = value;
    }
  },
  playing: function playing() {
    cc.log("dddddd");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdHVybnR3by5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvbnRlbnRjIiwidHlwZSIsIk5vZGUiLCJzcGVlZCIsInN0YXJ0Iiwic2V0X3ZhbHVlIiwidmFsdWUiLCJudW1faGVpZ2h0IiwiaGVpZ2h0Iiwic3Rhcl95X251bSIsIm5vd192YWx1ZSIsInkiLCJyYW5kb21OdW0iLCJyb2xsX3RvbnVtIiwieCIsIm1vdmVfcyIsInRpbWUiLCJtIiwibW92ZVRvIiwiZWFzaW5nIiwiZWFzZUN1YmljQWN0aW9uSW5PdXQiLCJydW5BY3Rpb24iLCJwbGF5aW5nIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsUUFBUSxFQUFDO0FBQ0xDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURKO0FBRUwsaUJBQVM7QUFGSixLQUREO0FBS1JDLElBQUFBLEtBQUssRUFBRTtBQUxDLEdBSFA7QUFXTDtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUFDLEVBQUFBLEtBekJLLG1CQXlCSSxDQUVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBR0gsR0EvQ0k7QUFtRExDLEVBQUFBLFNBbkRLLHFCQW1ES0MsS0FuREwsRUFtRFc7QUFDWixTQUFLQyxVQUFMLEdBQWtCLEtBQUtQLFFBQUwsQ0FBY1EsTUFBZCxHQUFxQixFQUF2QztBQUNBLFNBQUtDLFVBQUwsR0FBa0IsS0FBS0YsVUFBTCxHQUFrQixHQUFwQztBQUNBLFNBQUtHLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSxTQUFLVixRQUFMLENBQWNXLENBQWQsR0FBa0IsS0FBS0YsVUFBdkI7QUFDQSxTQUFLRyxTQUFMLEdBQWlCLENBQWpCOztBQUVBLFFBQUdOLEtBQUssR0FBRyxDQUFSLElBQWFBLEtBQUssR0FBRyxDQUF4QixFQUEwQjtBQUN0QjtBQUNIOztBQUNELFNBQUtJLFNBQUwsR0FBaUJKLEtBQWpCO0FBQ0EsU0FBS04sUUFBTCxDQUFjVyxDQUFkLEdBQWtCLEtBQUtGLFVBQUwsR0FBa0IsQ0FBQyxLQUFLQyxTQUFMLEdBQWlCLENBQWxCLElBQXVCLEdBQTNEO0FBRUgsR0FoRUk7QUFvRUxHLEVBQUFBLFVBcEVLLHNCQW9FTVAsS0FwRU4sRUFvRVk7QUFDYixRQUFHQSxLQUFLLEdBQUcsRUFBUixJQUFjQSxLQUFLLEdBQUcsQ0FBekIsRUFDSTs7QUFDSixRQUFHQSxLQUFLLEdBQUcsS0FBS0ksU0FBaEIsRUFBMEI7QUFDdEIsVUFBSUksQ0FBQyxHQUFHUixLQUFSLENBRHNCLENBRXRCOztBQUNBLFVBQUlTLE1BQU0sR0FBRyxDQUFDLEtBQUtMLFNBQUwsR0FBaUJJLENBQWxCLElBQXVCLEtBQUtQLFVBQXpDO0FBQ0EsVUFBSVMsSUFBSSxHQUFHRCxNQUFNLEdBQUMsS0FBS1osS0FBdkI7QUFDQSxVQUFJYyxDQUFDLEdBQUdyQixFQUFFLENBQUNzQixNQUFILENBQVVGLElBQVYsRUFBZ0IsQ0FBaEIsRUFBbUIsS0FBS2hCLFFBQUwsQ0FBY1csQ0FBZCxHQUFrQkksTUFBckMsQ0FBUjtBQUVBRSxNQUFBQSxDQUFDLENBQUNFLE1BQUYsQ0FBU3ZCLEVBQUUsQ0FBQ3dCLG9CQUFILEVBQVQ7QUFDQSxXQUFLcEIsUUFBTCxDQUFjcUIsU0FBZCxDQUF3QkosQ0FBeEI7QUFDQSxXQUFLUCxTQUFMLEdBQWlCSSxDQUFqQjtBQUNILEtBVkQsTUFXSTtBQUNBLFVBQUlDLE1BQU0sR0FBRyxDQUFDVCxLQUFLLEdBQUcsS0FBS0ksU0FBZCxJQUEyQixLQUFLSCxVQUE3QztBQUNBLFVBQUlTLElBQUksR0FBR0QsTUFBTSxHQUFHLEtBQUtaLEtBQXpCO0FBQ0EsVUFBSWMsQ0FBQyxHQUFHckIsRUFBRSxDQUFDc0IsTUFBSCxDQUFVRixJQUFWLEVBQWdCLENBQWhCLEVBQW1CLEtBQUtoQixRQUFMLENBQWNXLENBQWQsR0FBa0JJLE1BQXJDLENBQVI7QUFDQUUsTUFBQUEsQ0FBQyxDQUFDRSxNQUFGLENBQVN2QixFQUFFLENBQUN3QixvQkFBSCxFQUFUO0FBQ0EsV0FBS3BCLFFBQUwsQ0FBY3FCLFNBQWQsQ0FBd0JKLENBQXhCO0FBQ0EsV0FBS1AsU0FBTCxHQUFpQkosS0FBakI7QUFDSDtBQUNKLEdBMUZJO0FBNEZMZ0IsRUFBQUEsT0E1RksscUJBNEZJO0FBQ0wxQixJQUFBQSxFQUFFLENBQUMyQixHQUFILENBQU8sUUFBUDtBQUNILEdBOUZJLENBaUdMOztBQWpHSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY29udGVudGM6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3BlZWQ6IDMwMCwgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuICAgIC8vIG9uU2V0TnVtKHtudW0gPSA1fSl7XHJcbiAgICAvLyAgICAgLy/ojrflj5bmlbDlrZdMYWJlbOeahOS4quaVsFxyXG4gICAgLy8gICAgIGxldCBjaGlsZENvdW50ID0gdGhpcy5ub2RlX2xheW91dC5nZXRDaGlsZHJlbigpLmxlbmd0aDtcclxuICAgIC8vICAgICAvL+axguWHuuWNleS9jXnlgLxcclxuICAgIC8vICAgICBsZXQgdW5pdF95ID0gdGhpcy5ub2RlX2xheW91dC5oZWlnaHQgLyBjaGlsZENvdW50O1xyXG4gICAgXHJcbiAgICAvLyAgICAgY2MudHdlZW4odGhpcy5ub2RlX2xheW91dClcclxuICAgIC8vICAgICAgIC50bygwLjUsIHtwb3NpdGlvbjogY2MudjIodGhpcy5ub2RlX2xheW91dC54LCBudW0gKiB1bml0X3kgKyB1bml0X3kgLyAyKX0sIHtlYXNpbmc6IFwicXVhZEluT3V0XCJ9KVxyXG4gICAgLy8gICAgICAgLnN0YXJ0KCk7XHJcbiAgICAvLyAgIH0sXHJcbiAgICBcclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBcclxuICAgICAgICAvLyB2YXIgbGV2ZWwgPSB7XHJcbiAgICAgICAgLy8gICAgIG9uZTogJ+eKtuWFg+aPkumHkeiKse+8gScsXHJcbiAgICAgICAgLy8gICAgIHR3bzogJ+WFree6ouWFreWtkCcsIC8vIOWFreWtkFxyXG4gICAgICAgIC8vICAgICB0aHJlZTogJ+S6lOe6ouS6lOWtkCcsIC8vIOS6lOWtkFxyXG4gICAgICAgIC8vICAgICBmb3VyOiAn5pmu6YCa54q25YWDJyxcclxuICAgICAgICAvLyAgICAgZml2ZTogJ+WvueWggicsXHJcbiAgICAgICAgLy8gICAgIHNpeDogJ+S4iee6oicsXHJcbiAgICAgICAgLy8gICAgIHNldmVuOiAn5Zub6L+bJyxcclxuICAgICAgICAvLyAgICAgZWlnaHQ6ICfkuozkuL4nLFxyXG4gICAgICAgIC8vICAgICBuaW5lOiAn5LiA56eAJyxcclxuICAgICAgICAvLyAgICAgdGVuOiAn5rKh5pyJ5aWW5ZOm5Lqyfn5+fn4nXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyB0aGlzX2xldmVsOyAvLyDlrZjlgqjlvZPliY3nrYnnuqdcclxuICAgICAgICBcclxuICAgICAgICAvLyB0aGlzLnJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSo2KSArIDE7XHJcbiAgICAgICAgLy90aGlzLnNldF92YWx1ZSgxKTtcclxuXHJcbiAgICAgICAgLy90aGlzLnJvbGxfdG9udW0oMyk7XHJcblxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgXHJcblxyXG4gICAgc2V0X3ZhbHVlKHZhbHVlKXtcclxuICAgICAgICB0aGlzLm51bV9oZWlnaHQgPSB0aGlzLmNvbnRlbnRjLmhlaWdodC8xMjtcclxuICAgICAgICB0aGlzLnN0YXJfeV9udW0gPSB0aGlzLm51bV9oZWlnaHQgKiAwLjU7XHJcbiAgICAgICAgdGhpcy5ub3dfdmFsdWUgPSAwO1xyXG4gICAgICAgIHRoaXMuY29udGVudGMueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICB0aGlzLnJhbmRvbU51bSA9IDE7XHJcblxyXG4gICAgICAgIGlmKHZhbHVlID4gNiB8fCB2YWx1ZSA8IDEpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgdGhpcy5jb250ZW50Yy55ID0gdGhpcy5zdGFyX3lfbnVtICsgKHRoaXMubm93X3ZhbHVlIC0gMSkgKiAxMDA7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgcm9sbF90b251bSh2YWx1ZSl7XHJcbiAgICAgICAgaWYodmFsdWUgPiAxMCB8fCB2YWx1ZSA8IDEpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZih2YWx1ZSA8IHRoaXMubm93X3ZhbHVlKXtcclxuICAgICAgICAgICAgdmFyIHggPSB2YWx1ZTtcclxuICAgICAgICAgICAgLy92YWx1ZSArPSA2O1xyXG4gICAgICAgICAgICB2YXIgbW92ZV9zID0gKHRoaXMubm93X3ZhbHVlIC0geCkgKiB0aGlzLm51bV9oZWlnaHQ7XHJcbiAgICAgICAgICAgIHZhciB0aW1lID0gbW92ZV9zL3RoaXMuc3BlZWQ7XHJcbiAgICAgICAgICAgIHZhciBtID0gY2MubW92ZVRvKHRpbWUsIDAsIHRoaXMuY29udGVudGMueSAtIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50Yy5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh2YWx1ZSAtIHRoaXMubm93X3ZhbHVlKSAqIHRoaXMubnVtX2hlaWdodDtcclxuICAgICAgICAgICAgdmFyIHRpbWUgPSBtb3ZlX3MgLyB0aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnRjLnkgKyBtb3ZlX3MpO1xyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50Yy5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgcGxheWluZygpe1xyXG4gICAgICAgIGNjLmxvZyhcImRkZGRkZFwiKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19