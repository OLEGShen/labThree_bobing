
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/numing.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ca922d3BkhEHJVy0PRSATpF', 'numing');
// scripts/numing.js

"use strict";

window.member = {
  num: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    // ...
    // score label 的引用
    scoreDisplay: {
      "default": null,
      type: cc.Label
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    // ...
    member.num = 2;
  },
  start: function start() {},
  loseScore: function loseScore() {
    if (member.num > 2) member.num -= 1;
    this.scoreDisplay.string = member.num;
  },
  gainScore: function gainScore() {
    if (member.num < 10) member.num += 1;
    this.scoreDisplay.string = member.num;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcbnVtaW5nLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsIm1lbWJlciIsIm51bSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic2NvcmVEaXNwbGF5IiwidHlwZSIsIkxhYmVsIiwib25Mb2FkIiwic3RhcnQiLCJsb3NlU2NvcmUiLCJzdHJpbmciLCJnYWluU2NvcmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxHQUFnQjtBQUNaQyxFQUFBQSxHQUFHLEVBQUM7QUFEUSxDQUFoQjtBQUdBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUVMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUjtBQUNBO0FBQ0FDLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTLElBREM7QUFFVkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkM7QUFITixHQUZQO0FBVUw7QUFDQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFZO0FBQ2hCO0FBQ0FULElBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWI7QUFDSCxHQWRJO0FBZ0JMUyxFQUFBQSxLQWhCSyxtQkFnQkcsQ0FDUCxDQWpCSTtBQW1CTEMsRUFBQUEsU0FBUyxFQUFDLHFCQUFVO0FBQ2hCLFFBQUdYLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWhCLEVBQ0lELE1BQU0sQ0FBQ0MsR0FBUCxJQUFjLENBQWQ7QUFDSixTQUFLSyxZQUFMLENBQWtCTSxNQUFsQixHQUEyQlosTUFBTSxDQUFDQyxHQUFsQztBQUNILEdBdkJJO0FBeUJMWSxFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkIsUUFBR2IsTUFBTSxDQUFDQyxHQUFQLEdBQWEsRUFBaEIsRUFDSUQsTUFBTSxDQUFDQyxHQUFQLElBQWMsQ0FBZDtBQUNKLFNBQUtLLFlBQUwsQ0FBa0JNLE1BQWxCLEdBQTJCWixNQUFNLENBQUNDLEdBQWxDO0FBQ0g7QUE3QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsid2luZG93Lm1lbWJlciA9IHtcclxuICAgIG51bTpudWxsLFxyXG59O1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgLy8gc2NvcmUgbGFiZWwg55qE5byV55SoXHJcbiAgICAgICAgc2NvcmVEaXNwbGF5OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkxhYmVsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgbWVtYmVyLm51bSA9IDI7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBzdGFydCgpIHsgXHJcbiAgICB9LFxyXG5cclxuICAgIGxvc2VTY29yZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGlmKG1lbWJlci5udW0gPiAyKVxyXG4gICAgICAgICAgICBtZW1iZXIubnVtIC09IDE7XHJcbiAgICAgICAgdGhpcy5zY29yZURpc3BsYXkuc3RyaW5nID0gbWVtYmVyLm51bTtcclxuICAgIH0sXHJcblxyXG4gICAgZ2FpblNjb3JlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYobWVtYmVyLm51bSA8IDEwKVxyXG4gICAgICAgICAgICBtZW1iZXIubnVtICs9IDE7XHJcbiAgICAgICAgdGhpcy5zY29yZURpc3BsYXkuc3RyaW5nID0gbWVtYmVyLm51bTtcclxuICAgIH0sXHJcbiAgICBcclxufSk7XHJcblxyXG5cclxuXHJcbiJdfQ==