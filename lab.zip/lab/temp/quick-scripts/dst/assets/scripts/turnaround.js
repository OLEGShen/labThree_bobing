
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/turnaround.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '838e0xuhbRFZIpHyTYveDwT', 'turnaround');
// scripts/turnaround.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    content: {
      type: cc.Node,
      "default": null
    },
    speed: 300
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  // onSetNum({num = 5}){
  //     //获取数字Label的个数
  //     let childCount = this.node_layout.getChildren().length;
  //     //求出单位y值
  //     let unit_y = this.node_layout.height / childCount;
  //     cc.tween(this.node_layout)
  //       .to(0.5, {position: cc.v2(this.node_layout.x, num * unit_y + unit_y / 2)}, {easing: "quadInOut"})
  //       .start();
  //   },
  start: function start() {// this.num_height = this.content.height/12;
    // this.star_y_num = this.num_height * 0.5;
    // this.now_value = 0;
    // this.content.y = this.star_y_num;
    // var NumberArr = [];
    // this.randomNum = 1;
    // var level = {
    //     one: '状元插金花！',
    //     two: '六红六子', // 六子
    //     three: '五红五子', // 五子
    //     four: '普通状元',
    //     five: '对堂',
    //     six: '三红',
    //     seven: '四进',
    //     eight: '二举',
    //     nine: '一秀',
    //     ten: '没有奖哦亲~~~~~'
    // },
    // this_level; // 存储当前等级
    // this.randomNum = Math.floor(Math.random()*6) + 1;
    //this.set_value(1);
    //this.roll_tonum(4);
    //this.roll_tonum(2);
    // this.roll_tonum(6);
    // this.roll_tonum(1);
    //this.roll(2);
    // for(i = 0; i < 6; i++){
    //     var a = Math.floor(Math.random()*6) + 1;
    //     this.roll(a);
    //    // var m = cc.moveTo(1, 0, 50);
    //     //m.easing(cc.easeCubicActionInOut());
    //     NumberArr.push(a);
    // }
    // NumberArr.sort();
    // for(i = 0; i < 6; i++){
    //     cc.log(NumberArr[i]);
    // }
  },
  set_value: function set_value(value) {
    this.num_height = this.content.height / 12;
    this.star_y_num = this.num_height * 0.5;
    this.now_value = 0;
    this.content.y = this.star_y_num;
    this.randomNum = 1;

    if (value > 10 || value < 1) {
      return;
    }

    this.now_value = value;
    this.content.y = this.star_y_num + (this.now_value - 1) * 100;
  },
  roll_tonum: function roll_tonum(value) {
    if (value > 6 || value < 1) return;

    if (value < this.now_value) {
      var x = value; //value += 6;

      var move_s = (this.now_value - x) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.content.y - move_s);
      m.easing(cc.easeCubicActionInOut()); // this.content.runAction(m);
      // this.now_value = value - 6;
      // this.content.y -= 600;
      // var end_func = cc.callFunc(function(){
      //     this.now_value = x;
      //     this.content.y -= 600;
      // }.bind(this))
      // var seq = cc.sequence([m, end_func]);

      this.content.runAction(m);
      this.now_value = x;
    } else {
      var move_s = (value - this.now_value) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.content.y + move_s);
      m.easing(cc.easeCubicActionInOut());
      this.content.runAction(m);
      this.now_value = value;
    }
  },
  playing: function playing(value) {
    cc.log("dddddddddddd");
  },
  roll: function roll(value) {
    if (value > 6 || value < 1) return;
    value += 6;
    var move_s = (value - this.now_value) * 100;
    var time = move_s / this.speed;
    var m = cc.moveTo(time, 0, this.content.y + move_s);
    m.easing(cc.easeCubicActionInOut());
    this.content.runAction(m);
    var end_func = cc.callFunc(function () {
      this.now_value = value - 6;
      this.content.y -= 6 * 100;
    }.bind(this));
    this.content.runAction(end_func); //var seq = cc.sequence([m, end_func]);
    //this.content.runAction(seq);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdHVybmFyb3VuZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvbnRlbnQiLCJ0eXBlIiwiTm9kZSIsInNwZWVkIiwic3RhcnQiLCJzZXRfdmFsdWUiLCJ2YWx1ZSIsIm51bV9oZWlnaHQiLCJoZWlnaHQiLCJzdGFyX3lfbnVtIiwibm93X3ZhbHVlIiwieSIsInJhbmRvbU51bSIsInJvbGxfdG9udW0iLCJ4IiwibW92ZV9zIiwidGltZSIsIm0iLCJtb3ZlVG8iLCJlYXNpbmciLCJlYXNlQ3ViaWNBY3Rpb25Jbk91dCIsInJ1bkFjdGlvbiIsInBsYXlpbmciLCJsb2ciLCJyb2xsIiwiZW5kX2Z1bmMiLCJjYWxsRnVuYyIsImJpbmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxPQUFPLEVBQUM7QUFDSkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBREw7QUFFSixpQkFBUztBQUZMLEtBREE7QUFLUkMsSUFBQUEsS0FBSyxFQUFFO0FBTEMsR0FIUDtBQVdMO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQUMsRUFBQUEsS0F6QkssbUJBeUJJLENBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDQztBQUNBO0FBQ0E7QUFFSCxHQXJFSTtBQXlFTEMsRUFBQUEsU0F6RUsscUJBeUVLQyxLQXpFTCxFQXlFVztBQUNaLFNBQUtDLFVBQUwsR0FBa0IsS0FBS1AsT0FBTCxDQUFhUSxNQUFiLEdBQW9CLEVBQXRDO0FBQ0EsU0FBS0MsVUFBTCxHQUFrQixLQUFLRixVQUFMLEdBQWtCLEdBQXBDO0FBQ0EsU0FBS0csU0FBTCxHQUFpQixDQUFqQjtBQUNBLFNBQUtWLE9BQUwsQ0FBYVcsQ0FBYixHQUFpQixLQUFLRixVQUF0QjtBQUNBLFNBQUtHLFNBQUwsR0FBaUIsQ0FBakI7O0FBSUEsUUFBR04sS0FBSyxHQUFHLEVBQVIsSUFBY0EsS0FBSyxHQUFHLENBQXpCLEVBQTJCO0FBQ3ZCO0FBQ0g7O0FBQ0QsU0FBS0ksU0FBTCxHQUFpQkosS0FBakI7QUFDQSxTQUFLTixPQUFMLENBQWFXLENBQWIsR0FBaUIsS0FBS0YsVUFBTCxHQUFrQixDQUFDLEtBQUtDLFNBQUwsR0FBaUIsQ0FBbEIsSUFBdUIsR0FBMUQ7QUFFSCxHQXhGSTtBQTRGTEcsRUFBQUEsVUE1Rkssc0JBNEZNUCxLQTVGTixFQTRGWTtBQUNiLFFBQUdBLEtBQUssR0FBRyxDQUFSLElBQWFBLEtBQUssR0FBRyxDQUF4QixFQUNJOztBQUNKLFFBQUdBLEtBQUssR0FBRyxLQUFLSSxTQUFoQixFQUEwQjtBQUN0QixVQUFJSSxDQUFDLEdBQUdSLEtBQVIsQ0FEc0IsQ0FFdEI7O0FBQ0EsVUFBSVMsTUFBTSxHQUFHLENBQUMsS0FBS0wsU0FBTCxHQUFpQkksQ0FBbEIsSUFBdUIsS0FBS1AsVUFBekM7QUFDQSxVQUFJUyxJQUFJLEdBQUdELE1BQU0sR0FBQyxLQUFLWixLQUF2QjtBQUNBLFVBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBRUFFLE1BQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVCxFQVBzQixDQVN0QjtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFdBQUtQLFNBQUwsR0FBaUJJLENBQWpCO0FBQ0gsS0FyQkQsTUFzQkk7QUFDQSxVQUFJQyxNQUFNLEdBQUcsQ0FBQ1QsS0FBSyxHQUFHLEtBQUtJLFNBQWQsSUFBMkIsS0FBS0gsVUFBN0M7QUFDQSxVQUFJUyxJQUFJLEdBQUdELE1BQU0sR0FBRyxLQUFLWixLQUF6QjtBQUNBLFVBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBQ0FFLE1BQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVDtBQUNBLFdBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFdBQUtQLFNBQUwsR0FBaUJKLEtBQWpCO0FBQ0g7QUFDSixHQTdISTtBQStITGdCLEVBQUFBLE9BL0hLLG1CQStIR2hCLEtBL0hILEVBK0hTO0FBQ1ZWLElBQUFBLEVBQUUsQ0FBQzJCLEdBQUgsQ0FBTyxjQUFQO0FBQ0gsR0FqSUk7QUFtSUxDLEVBQUFBLElBbklLLGdCQW1JQWxCLEtBbklBLEVBbUlNO0FBQ1AsUUFBR0EsS0FBSyxHQUFHLENBQVIsSUFBYUEsS0FBSyxHQUFHLENBQXhCLEVBQ0k7QUFDQUEsSUFBQUEsS0FBSyxJQUFJLENBQVQ7QUFFQSxRQUFJUyxNQUFNLEdBQUcsQ0FBQ1QsS0FBSyxHQUFHLEtBQUtJLFNBQWQsSUFBMkIsR0FBeEM7QUFDQSxRQUFJTSxJQUFJLEdBQUdELE1BQU0sR0FBQyxLQUFLWixLQUF2QjtBQUNBLFFBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBRUFFLElBQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVDtBQUNBLFNBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFFBQUlRLFFBQVEsR0FBRzdCLEVBQUUsQ0FBQzhCLFFBQUgsQ0FBWSxZQUFVO0FBQ2pDLFdBQUtoQixTQUFMLEdBQWlCSixLQUFLLEdBQUcsQ0FBekI7QUFDQSxXQUFLTixPQUFMLENBQWFXLENBQWIsSUFBa0IsSUFBSSxHQUF0QjtBQUNILEtBSDBCLENBR3pCZ0IsSUFIeUIsQ0FHcEIsSUFIb0IsQ0FBWixDQUFmO0FBSUEsU0FBSzNCLE9BQUwsQ0FBYXFCLFNBQWIsQ0FBdUJJLFFBQXZCLEVBZkcsQ0FnQkg7QUFDQTtBQUNQLEdBckpJLENBdUpMOztBQXZKSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY29udGVudDp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzcGVlZDogMzAwLCAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG4gICAgLy8gb25TZXROdW0oe251bSA9IDV9KXtcclxuICAgIC8vICAgICAvL+iOt+WPluaVsOWtl0xhYmVs55qE5Liq5pWwXHJcbiAgICAvLyAgICAgbGV0IGNoaWxkQ291bnQgPSB0aGlzLm5vZGVfbGF5b3V0LmdldENoaWxkcmVuKCkubGVuZ3RoO1xyXG4gICAgLy8gICAgIC8v5rGC5Ye65Y2V5L2NeeWAvFxyXG4gICAgLy8gICAgIGxldCB1bml0X3kgPSB0aGlzLm5vZGVfbGF5b3V0LmhlaWdodCAvIGNoaWxkQ291bnQ7XHJcbiAgICBcclxuICAgIC8vICAgICBjYy50d2Vlbih0aGlzLm5vZGVfbGF5b3V0KVxyXG4gICAgLy8gICAgICAgLnRvKDAuNSwge3Bvc2l0aW9uOiBjYy52Mih0aGlzLm5vZGVfbGF5b3V0LngsIG51bSAqIHVuaXRfeSArIHVuaXRfeSAvIDIpfSwge2Vhc2luZzogXCJxdWFkSW5PdXRcIn0pXHJcbiAgICAvLyAgICAgICAuc3RhcnQoKTtcclxuICAgIC8vICAgfSxcclxuICAgIFxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIC8vIHRoaXMubnVtX2hlaWdodCA9IHRoaXMuY29udGVudC5oZWlnaHQvMTI7XHJcbiAgICAgICAgLy8gdGhpcy5zdGFyX3lfbnVtID0gdGhpcy5udW1faGVpZ2h0ICogMC41O1xyXG4gICAgICAgIC8vIHRoaXMubm93X3ZhbHVlID0gMDtcclxuICAgICAgICAvLyB0aGlzLmNvbnRlbnQueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICAvLyB2YXIgTnVtYmVyQXJyID0gW107XHJcbiAgICAgICAgLy8gdGhpcy5yYW5kb21OdW0gPSAxO1xyXG5cclxuXHJcblxyXG4gICAgICAgIC8vIHZhciBsZXZlbCA9IHtcclxuICAgICAgICAvLyAgICAgb25lOiAn54q25YWD5o+S6YeR6Iqx77yBJyxcclxuICAgICAgICAvLyAgICAgdHdvOiAn5YWt57qi5YWt5a2QJywgLy8g5YWt5a2QXHJcbiAgICAgICAgLy8gICAgIHRocmVlOiAn5LqU57qi5LqU5a2QJywgLy8g5LqU5a2QXHJcbiAgICAgICAgLy8gICAgIGZvdXI6ICfmma7pgJrnirblhYMnLFxyXG4gICAgICAgIC8vICAgICBmaXZlOiAn5a+55aCCJyxcclxuICAgICAgICAvLyAgICAgc2l4OiAn5LiJ57qiJyxcclxuICAgICAgICAvLyAgICAgc2V2ZW46ICflm5vov5snLFxyXG4gICAgICAgIC8vICAgICBlaWdodDogJ+S6jOS4vicsXHJcbiAgICAgICAgLy8gICAgIG5pbmU6ICfkuIDnp4AnLFxyXG4gICAgICAgIC8vICAgICB0ZW46ICfmsqHmnInlpZblk6bkurJ+fn5+fidcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIHRoaXNfbGV2ZWw7IC8vIOWtmOWCqOW9k+WJjeetiee6p1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIHRoaXMucmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjYpICsgMTtcclxuICAgICAgICAvL3RoaXMuc2V0X3ZhbHVlKDEpO1xyXG5cclxuICAgICAgICAvL3RoaXMucm9sbF90b251bSg0KTtcclxuICAgICAgICAvL3RoaXMucm9sbF90b251bSgyKTtcclxuICAgICAgICAvLyB0aGlzLnJvbGxfdG9udW0oNik7XHJcbiAgICAgICAgLy8gdGhpcy5yb2xsX3RvbnVtKDEpO1xyXG4gICAgICAgIC8vdGhpcy5yb2xsKDIpO1xyXG4gICAgICAgIC8vIGZvcihpID0gMDsgaSA8IDY7IGkrKyl7XHJcbiAgICAgICAgLy8gICAgIHZhciBhID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjYpICsgMTtcclxuICAgICAgICAvLyAgICAgdGhpcy5yb2xsKGEpO1xyXG4gICAgICAgIC8vICAgIC8vIHZhciBtID0gY2MubW92ZVRvKDEsIDAsIDUwKTtcclxuICAgICAgICAvLyAgICAgLy9tLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAvLyAgICAgTnVtYmVyQXJyLnB1c2goYSk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgLy8gTnVtYmVyQXJyLnNvcnQoKTtcclxuICAgICAgICAvLyBmb3IoaSA9IDA7IGkgPCA2OyBpKyspe1xyXG4gICAgICAgIC8vICAgICBjYy5sb2coTnVtYmVyQXJyW2ldKTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBcclxuXHJcbiAgICBzZXRfdmFsdWUodmFsdWUpe1xyXG4gICAgICAgIHRoaXMubnVtX2hlaWdodCA9IHRoaXMuY29udGVudC5oZWlnaHQvMTI7XHJcbiAgICAgICAgdGhpcy5zdGFyX3lfbnVtID0gdGhpcy5udW1faGVpZ2h0ICogMC41O1xyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gMDtcclxuICAgICAgICB0aGlzLmNvbnRlbnQueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICB0aGlzLnJhbmRvbU51bSA9IDE7XHJcblxyXG5cclxuXHJcbiAgICAgICAgaWYodmFsdWUgPiAxMCB8fCB2YWx1ZSA8IDEpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnkgPSB0aGlzLnN0YXJfeV9udW0gKyAodGhpcy5ub3dfdmFsdWUgLSAxKSAqIDEwMDtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICByb2xsX3RvbnVtKHZhbHVlKXtcclxuICAgICAgICBpZih2YWx1ZSA+IDYgfHwgdmFsdWUgPCAxKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYodmFsdWUgPCB0aGlzLm5vd192YWx1ZSl7XHJcbiAgICAgICAgICAgIHZhciB4ID0gdmFsdWU7XHJcbiAgICAgICAgICAgIC8vdmFsdWUgKz0gNjtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh0aGlzLm5vd192YWx1ZSAtIHgpICogdGhpcy5udW1faGVpZ2h0O1xyXG4gICAgICAgICAgICB2YXIgdGltZSA9IG1vdmVfcy90aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSAtIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMuY29udGVudC5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMubm93X3ZhbHVlID0gdmFsdWUgLSA2O1xyXG4gICAgICAgICAgICAvLyB0aGlzLmNvbnRlbnQueSAtPSA2MDA7XHJcblxyXG5cclxuICAgICAgICAgICAgLy8gdmFyIGVuZF9mdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuY29udGVudC55IC09IDYwMDtcclxuICAgICAgICAgICAgLy8gfS5iaW5kKHRoaXMpKVxyXG4gICAgICAgICAgICAvLyB2YXIgc2VxID0gY2Muc2VxdWVuY2UoW20sIGVuZF9mdW5jXSk7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGVudC5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh2YWx1ZSAtIHRoaXMubm93X3ZhbHVlKSAqIHRoaXMubnVtX2hlaWdodDtcclxuICAgICAgICAgICAgdmFyIHRpbWUgPSBtb3ZlX3MgLyB0aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSArIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIG0uZWFzaW5nKGNjLmVhc2VDdWJpY0FjdGlvbkluT3V0KCkpO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQucnVuQWN0aW9uKG0pO1xyXG4gICAgICAgICAgICB0aGlzLm5vd192YWx1ZSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgcGxheWluZyh2YWx1ZSl7XHJcbiAgICAgICAgY2MubG9nKFwiZGRkZGRkZGRkZGRkXCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICByb2xsKHZhbHVlKXtcclxuICAgICAgICBpZih2YWx1ZSA+IDYgfHwgdmFsdWUgPCAxKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIHZhbHVlICs9IDY7XHJcblxyXG4gICAgICAgICAgICB2YXIgbW92ZV9zID0gKHZhbHVlIC0gdGhpcy5ub3dfdmFsdWUpICogMTAwO1xyXG4gICAgICAgICAgICB2YXIgdGltZSA9IG1vdmVfcy90aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSArIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LnJ1bkFjdGlvbihtKTtcclxuICAgICAgICAgICAgdmFyIGVuZF9mdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWUgLSA2O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LnkgLT0gNiAqIDEwMDtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKVxyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQucnVuQWN0aW9uKGVuZF9mdW5jKTtcclxuICAgICAgICAgICAgLy92YXIgc2VxID0gY2Muc2VxdWVuY2UoW20sIGVuZF9mdW5jXSk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5jb250ZW50LnJ1bkFjdGlvbihzZXEpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==