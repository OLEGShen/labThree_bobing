
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/count');
require('./assets/scripts/cow');
require('./assets/scripts/gotoanswer');
require('./assets/scripts/guizejs');
require('./assets/scripts/homejs');
require('./assets/scripts/numing');
require('./assets/scripts/rolltwo');
require('./assets/scripts/toanswersss');
require('./assets/scripts/tonum');
require('./assets/scripts/totouzi');
require('./assets/scripts/totouzitwo');
require('./assets/scripts/turnall');
require('./assets/scripts/turnaround');
require('./assets/scripts/turntwo');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/cow.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4d7cd0nKVROJ4NeYg7NYqI9', 'cow');
// scripts/cow.js

"use strict";

var cow_skin = cc.Class({
  name: "cow_skin",
  properties: {
    cows: {
      "default": [],
      type: [cc.SpriteFrame]
    }
  }
});
cc.Class({
  "extends": cc.Component,
  properties: {
    cow_set: {
      "default": [],
      type: [cow_skin]
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.intervalTime = 0;
  },
  start: function start() {},
  update: function update(dt) {
    this.intervalTime += dt;
    var index = Math.floor(this.intervalTime / 0.2);
    index = index % 5; //cc.log(index);

    var cowSet = this.cow_set[0];
    var sprite = this.node.getComponent(cc.Sprite);
    sprite.spriteFrame = cowSet.cows[index];
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY293LmpzIl0sIm5hbWVzIjpbImNvd19za2luIiwiY2MiLCJDbGFzcyIsIm5hbWUiLCJwcm9wZXJ0aWVzIiwiY293cyIsInR5cGUiLCJTcHJpdGVGcmFtZSIsIkNvbXBvbmVudCIsImNvd19zZXQiLCJvbkxvYWQiLCJpbnRlcnZhbFRpbWUiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiaW5kZXgiLCJNYXRoIiwiZmxvb3IiLCJjb3dTZXQiLCJzcHJpdGUiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBTUEsUUFBUSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUN0QkMsRUFBQUEsSUFBSSxFQUFDLFVBRGlCO0FBRXRCQyxFQUFBQSxVQUFVLEVBQUM7QUFDUEMsSUFBQUEsSUFBSSxFQUFDO0FBQ0QsaUJBQVEsRUFEUDtBQUVEQyxNQUFBQSxJQUFJLEVBQUMsQ0FBQ0wsRUFBRSxDQUFDTSxXQUFKO0FBRko7QUFERTtBQUZXLENBQVQsQ0FBakI7QUFVQU4sRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNPLFNBRFA7QUFHTEosRUFBQUEsVUFBVSxFQUFFO0FBQ1JLLElBQUFBLE9BQU8sRUFBQztBQUNKLGlCQUFRLEVBREo7QUFFSkgsTUFBQUEsSUFBSSxFQUFDLENBQUNOLFFBQUQ7QUFGRDtBQURBLEdBSFA7QUFVTDtBQUVBVSxFQUFBQSxNQVpLLG9CQVlLO0FBQ04sU0FBS0MsWUFBTCxHQUFvQixDQUFwQjtBQUNILEdBZEk7QUFnQkxDLEVBQUFBLEtBaEJLLG1CQWdCSSxDQUVSLENBbEJJO0FBcUJMQyxFQUFBQSxNQXJCSyxrQkFxQkdDLEVBckJILEVBcUJPO0FBQ1IsU0FBS0gsWUFBTCxJQUFxQkcsRUFBckI7QUFDQSxRQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXLEtBQUtOLFlBQUwsR0FBb0IsR0FBL0IsQ0FBWjtBQUVBSSxJQUFBQSxLQUFLLEdBQUdBLEtBQUssR0FBRyxDQUFoQixDQUpRLENBS1I7O0FBQ0EsUUFBSUcsTUFBTSxHQUFHLEtBQUtULE9BQUwsQ0FBYSxDQUFiLENBQWI7QUFFQSxRQUFJVSxNQUFNLEdBQUcsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsTUFBMUIsQ0FBYjtBQUNBSCxJQUFBQSxNQUFNLENBQUNJLFdBQVAsR0FBcUJMLE1BQU0sQ0FBQ2IsSUFBUCxDQUFZVSxLQUFaLENBQXJCO0FBQ0g7QUEvQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY293X3NraW4gPSBjYy5DbGFzcyh7XHJcbiAgICBuYW1lOlwiY293X3NraW5cIixcclxuICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgIGNvd3M6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOltjYy5TcHJpdGVGcmFtZV1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBjb3dfc2V0OntcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgdHlwZTpbY293X3NraW5dXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuaW50ZXJ2YWxUaW1lID0gMDtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmludGVydmFsVGltZSArPSBkdDtcclxuICAgICAgICBsZXQgaW5kZXggPSBNYXRoLmZsb29yKHRoaXMuaW50ZXJ2YWxUaW1lIC8gMC4yKTtcclxuICAgICAgICBcclxuICAgICAgICBpbmRleCA9IGluZGV4ICUgNTtcclxuICAgICAgICAvL2NjLmxvZyhpbmRleCk7XHJcbiAgICAgICAgbGV0IGNvd1NldCA9IHRoaXMuY293X3NldFswXTtcclxuXHJcbiAgICAgICAgbGV0IHNwcml0ZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBjb3dTZXQuY293c1tpbmRleF07XHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/homejs.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '39b91kgY1lElZ46sYsN0T+i', 'homejs');
// scripts/homejs.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  toguize: function toguize() {
    cc.director.loadScene("guize");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcaG9tZWpzLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwidG9ndWl6ZSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZRLEdBSFA7QUFxQkw7QUFFQUMsRUFBQUEsTUF2Qkssb0JBdUJLLENBQUUsQ0F2QlA7QUF3QkxDLEVBQUFBLE9BQU8sRUFBQyxtQkFBVTtBQUNkTCxJQUFBQSxFQUFFLENBQUNNLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixPQUF0QjtBQUNILEdBMUJJO0FBMkJMQyxFQUFBQSxLQTNCSyxtQkEyQkksQ0FFUixDQTdCSSxDQStCTDs7QUEvQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxyXG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIGJhcjoge1xyXG4gICAgICAgIC8vICAgICBnZXQgKCkge1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuIHRoaXMuX2JhcjtcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fYmFyID0gdmFsdWU7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge30sXHJcbiAgICB0b2d1aXplOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiZ3VpemVcIilcclxuICAgIH0sXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/gotoanswer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '08df4upQRBLSZyODMqCJOvk', 'gotoanswer');
// scripts/gotoanswer.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  toanswer: function toanswer() {
    cc.director.loadScene("playing");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZ290b2Fuc3dlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsInRvYW5zd2VyIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLENBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlEsR0FIUDtBQXFCTDtBQUVBQyxFQUFBQSxNQXZCSyxvQkF1QkssQ0FBRSxDQXZCUDtBQXdCTEMsRUFBQUEsUUFBUSxFQUFDLG9CQUFVO0FBQ2ZMLElBQUFBLEVBQUUsQ0FBQ00sUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBQ0gsR0ExQkk7QUEyQkxDLEVBQUFBLEtBM0JLLG1CQTJCSSxDQUVSLENBN0JJLENBK0JMOztBQS9CSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsICAgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgICBzZXJpYWxpemFibGU6IHRydWUsICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gYmFyOiB7XHJcbiAgICAgICAgLy8gICAgIGdldCAoKSB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xyXG4gICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgIC8vICAgICBzZXQgKHZhbHVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7fSxcclxuICAgIHRvYW5zd2VyOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwicGxheWluZ1wiKVxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/guizejs.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cefadw74nJDuoyI4ym3iNxp', 'guizejs');
// scripts/guizejs.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  togame: function togame() {
    cc.director.loadScene("game");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZ3VpemVqcy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsInRvZ2FtZSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZRLEdBSFA7QUFxQkw7QUFFQUMsRUFBQUEsTUF2Qkssb0JBdUJLLENBQUUsQ0F2QlA7QUF3QkxDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVTtBQUNiTCxJQUFBQSxFQUFFLENBQUNNLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBMUJJO0FBMkJMQyxFQUFBQSxLQTNCSyxtQkEyQkksQ0FFUixDQTdCSSxDQStCTDs7QUEvQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxyXG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIGJhcjoge1xyXG4gICAgICAgIC8vICAgICBnZXQgKCkge1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuIHRoaXMuX2JhcjtcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fYmFyID0gdmFsdWU7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge30sXHJcbiAgICB0b2dhbWU6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJnYW1lXCIpXHJcbiAgICB9LFxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/numing.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ca922d3BkhEHJVy0PRSATpF', 'numing');
// scripts/numing.js

"use strict";

window.member = {
  num: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    // ...
    // score label 的引用
    scoreDisplay: {
      "default": null,
      type: cc.Label
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    // ...
    member.num = 2;
  },
  start: function start() {},
  loseScore: function loseScore() {
    if (member.num > 2) member.num -= 1;
    this.scoreDisplay.string = member.num;
  },
  gainScore: function gainScore() {
    if (member.num < 10) member.num += 1;
    this.scoreDisplay.string = member.num;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcbnVtaW5nLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsIm1lbWJlciIsIm51bSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic2NvcmVEaXNwbGF5IiwidHlwZSIsIkxhYmVsIiwib25Mb2FkIiwic3RhcnQiLCJsb3NlU2NvcmUiLCJzdHJpbmciLCJnYWluU2NvcmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxHQUFnQjtBQUNaQyxFQUFBQSxHQUFHLEVBQUM7QUFEUSxDQUFoQjtBQUdBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUVMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUjtBQUNBO0FBQ0FDLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTLElBREM7QUFFVkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkM7QUFITixHQUZQO0FBVUw7QUFDQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFZO0FBQ2hCO0FBQ0FULElBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWI7QUFDSCxHQWRJO0FBZ0JMUyxFQUFBQSxLQWhCSyxtQkFnQkcsQ0FDUCxDQWpCSTtBQW1CTEMsRUFBQUEsU0FBUyxFQUFDLHFCQUFVO0FBQ2hCLFFBQUdYLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWhCLEVBQ0lELE1BQU0sQ0FBQ0MsR0FBUCxJQUFjLENBQWQ7QUFDSixTQUFLSyxZQUFMLENBQWtCTSxNQUFsQixHQUEyQlosTUFBTSxDQUFDQyxHQUFsQztBQUNILEdBdkJJO0FBeUJMWSxFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkIsUUFBR2IsTUFBTSxDQUFDQyxHQUFQLEdBQWEsRUFBaEIsRUFDSUQsTUFBTSxDQUFDQyxHQUFQLElBQWMsQ0FBZDtBQUNKLFNBQUtLLFlBQUwsQ0FBa0JNLE1BQWxCLEdBQTJCWixNQUFNLENBQUNDLEdBQWxDO0FBQ0g7QUE3QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsid2luZG93Lm1lbWJlciA9IHtcclxuICAgIG51bTpudWxsLFxyXG59O1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgLy8gc2NvcmUgbGFiZWwg55qE5byV55SoXHJcbiAgICAgICAgc2NvcmVEaXNwbGF5OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkxhYmVsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICAgICAgbWVtYmVyLm51bSA9IDI7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBzdGFydCgpIHsgXHJcbiAgICB9LFxyXG5cclxuICAgIGxvc2VTY29yZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGlmKG1lbWJlci5udW0gPiAyKVxyXG4gICAgICAgICAgICBtZW1iZXIubnVtIC09IDE7XHJcbiAgICAgICAgdGhpcy5zY29yZURpc3BsYXkuc3RyaW5nID0gbWVtYmVyLm51bTtcclxuICAgIH0sXHJcblxyXG4gICAgZ2FpblNjb3JlOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYobWVtYmVyLm51bSA8IDEwKVxyXG4gICAgICAgICAgICBtZW1iZXIubnVtICs9IDE7XHJcbiAgICAgICAgdGhpcy5zY29yZURpc3BsYXkuc3RyaW5nID0gbWVtYmVyLm51bTtcclxuICAgIH0sXHJcbiAgICBcclxufSk7XHJcblxyXG5cclxuXHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/totouzitwo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '20557XcOuRIAKWKzLdBkwGk', 'totouzitwo');
// scripts/totouzitwo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  totwo: function totwo() {
    cc.director.loadScene("touzitwo");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdG90b3V6aXR3by5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsInRvdHdvIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFPTEMsRUFBQUEsTUFQSyxvQkFPSyxDQUFFLENBUFA7QUFRTEMsRUFBQUEsS0FBSyxFQUFDLGlCQUFVO0FBQ1pMLElBQUFBLEVBQUUsQ0FBQ00sUUFBSCxDQUFZQyxTQUFaLENBQXNCLFVBQXRCO0FBQ0gsR0FWSTtBQVdMQyxFQUFBQSxLQVhLLG1CQVdJLENBRVIsQ0FiSSxDQWVMOztBQWZLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCAoKSB7fSxcclxuICAgIHRvdHdvOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwidG91eml0d29cIilcclxuICAgIH0sXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/toanswersss.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd9d870fp7BP3Lt7UXPXcM1F', 'toanswersss');
// scripts/toanswersss.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  to: function to() {
    cc.director.loadScene("playingtwo");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdG9hbnN3ZXJzc3MuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJ0byIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLE1BUEssb0JBT0ssQ0FBRSxDQVBQO0FBUUxDLEVBQUFBLEVBQUUsRUFBQyxjQUFVO0FBQ1RMLElBQUFBLEVBQUUsQ0FBQ00sUUFBSCxDQUFZQyxTQUFaLENBQXNCLFlBQXRCO0FBQ0gsR0FWSTtBQVdMQyxFQUFBQSxLQVhLLG1CQVdJLENBRVIsQ0FiSSxDQWVMOztBQWZLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCAoKSB7fSxcclxuICAgIHRvOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwicGxheWluZ3R3b1wiKTtcclxuICAgIH0sXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/rolltwo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2daa975/WpIJYnNzvH4XyTB', 'rolltwo');
// scripts/rolltwo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
window.TheNum = {
  num: null
};
cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {
    var level = {
      one: '状元插金花！',
      two: '六红六子',
      // 六子
      three: '五红五子',
      // 五子
      four: '普通状元',
      five: '对堂',
      six: '三红',
      seven: '四进',
      eight: '二举',
      nine: '一秀',
      ten: '没有奖哦亲~~~~~'
    },
        this_level; // 存储当前等级
    //  存储当前随机数组

    var NumberArr = [];

    if (TheNum.num == null) {
      TheNum.num = 1;
    } else TheNum.num += 1;

    var numMax = member.num;

    if (TheNum.num > numMax) {
      TheNum.num = 1;
    } //  生成随机数据


    var a = Math.floor(Math.random() * 6) + 1,
        b = Math.floor(Math.random() * 6) + 1,
        c = Math.floor(Math.random() * 6) + 1,
        d = Math.floor(Math.random() * 6) + 1,
        e = Math.floor(Math.random() * 6) + 1,
        f = Math.floor(Math.random() * 6) + 1;
    g = TheNum.num;
    cc.log(g);
    cc.find("Canvas/rolling").getComponent("turnaround").set_value(a);
    cc.find("Canvas/rollingtwo").getComponent("turntwo").set_value(b);
    cc.find("Canvas/rollingt").getComponent("turnaround").set_value(c);
    cc.find("Canvas/rollingf").getComponent("turnaround").set_value(d);
    cc.find("Canvas/rollingfive").getComponent("turnaround").set_value(e);
    cc.find("Canvas/rollingsix").getComponent("turnaround").set_value(f);
    cc.find("Canvas/who").getComponent("turnaround").set_value(g); // 数据进入数组，排序

    NumberArr.push(a, b, c, d, e, f);
    NumberArr.sort(); //存储当前 “四” 的个数

    var isfour = 0;

    for (var i = 0; i < NumberArr.length; i++) {
      if (NumberArr[i] == 4) {
        isfour = isfour + 1;
      }
    } // 判断 “四” 的个数属于哪一等级;


    switch (isfour) {
      case 1:
        for (var i = 0; i < NumberArr.length; i++) {
          //存储当前相同的数量，判断是否为四进
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          }
        } // 等到上面遍历执行完再进行判断属于哪个级别


        if (ContrastArr.length === 4) {
          this_level = level.seven; //四进

          cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
          break;
        } else if (ContrastArr.length === 5) {
          this_level = level.three; //五红

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
          break;
        } else if (ContrastArr.length === 6) {
          this_level = level.two; //六红

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
          break;
        } else {
          // 判断一下，是 "对堂"" or ”一秀“，对堂就是顺子，123456，一秀就是一个只有4；
          var isContinuityArray = false;
          var array = NumberArr;
          var arrayCount = array.length;

          for (var i = 0; i < arrayCount; i++) {
            var currentArr = Number(array[i]) + 1;
            var nestArr = Number(array[i + 1]);

            if (i + 1 == arrayCount) {
              currentArr = Number(array[i]);
              nestArr = Number(array[i]);
            }

            if (currentArr != nestArr) {
              isContinuityArray = false;
              break;
            } else {
              isContinuityArray = true;
            }
          }

          if (isContinuityArray) {
            this_level = level.five;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(2);
            break;
          } else {
            this_level = level.nine;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(6);
            break;
          }
        }

        ;
        break;

      case 2:
        for (var i = 0; i < NumberArr.length; i++) {
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          } // 判断是 4进 or 二举


          if (ContrastArr.length === 4) {
            this_level = level.seven;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
            break;
          } else {
            this_level = level.eight;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(5);
          }
        }

        ;
        break;

      case 3:
        this_level = level.six;
        cc.find("Canvas/answer").getComponent("turnaround").set_value(3);
        break;

      case 4:
        // 判断是 "普通状元" or "状元插金花"，普通就是4个四，插金花就是  4个四 + 2个1 ；
        var one = 0;

        for (var i = 0; i < NumberArr.length; i++) {
          if (NumberArr[i] === 1) {
            one = one + 1;
          }
        }

        if (one == 2) {
          this_level = level.one; // 插金花

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        } else {
          this_level = level.four; //普通状元

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        }

        break;

      case 5:
        this_level = level.three; // 五红五子

        cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        break;

      case 6:
        this_level = level.two; //六红六子

        cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        break;

      default:
        // 就是页面都没有四,来判断是否属于 “五子” 和 “六子” 和 “四进” 中的哪一种;
        for (var i = 0; i < NumberArr.length; i++) {
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          }

          if (ContrastArr.length === 4) {
            this_level = level.seven; //四进

            cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
            break;
          } else if (ContrastArr.length === 5) {
            this_level = level.three; //五子

            cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
            break;
          } else if (ContrastArr.length === 6) {
            this_level = level.two; //六子

            cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
            break;
          } else {
            this_level = level.ten;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(7);
          }
        }

        ;
        break;
    }

    cc.log(this_level);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccm9sbHR3by5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJUaGVOdW0iLCJudW0iLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0IiwibGV2ZWwiLCJvbmUiLCJ0d28iLCJ0aHJlZSIsImZvdXIiLCJmaXZlIiwic2l4Iiwic2V2ZW4iLCJlaWdodCIsIm5pbmUiLCJ0ZW4iLCJ0aGlzX2xldmVsIiwiTnVtYmVyQXJyIiwibnVtTWF4IiwibWVtYmVyIiwiYSIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsImIiLCJjIiwiZCIsImUiLCJmIiwiZyIsImxvZyIsImZpbmQiLCJnZXRDb21wb25lbnQiLCJzZXRfdmFsdWUiLCJwdXNoIiwic29ydCIsImlzZm91ciIsImkiLCJsZW5ndGgiLCJDb250cmFzdEFyciIsImoiLCJpc0NvbnRpbnVpdHlBcnJheSIsImFycmF5IiwiYXJyYXlDb3VudCIsImN1cnJlbnRBcnIiLCJOdW1iZXIiLCJuZXN0QXJyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBQSxNQUFNLENBQUNDLE1BQVAsR0FBZ0I7QUFDWkMsRUFBQUEsR0FBRyxFQUFFO0FBRE8sQ0FBaEI7QUFHQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFNTEMsRUFBQUEsS0FOSyxtQkFNSTtBQUVMLFFBQUlDLEtBQUssR0FBRztBQUNSQyxNQUFBQSxHQUFHLEVBQUUsUUFERztBQUVSQyxNQUFBQSxHQUFHLEVBQUUsTUFGRztBQUVLO0FBQ2JDLE1BQUFBLEtBQUssRUFBRSxNQUhDO0FBR087QUFDZkMsTUFBQUEsSUFBSSxFQUFFLE1BSkU7QUFLUkMsTUFBQUEsSUFBSSxFQUFFLElBTEU7QUFNUkMsTUFBQUEsR0FBRyxFQUFFLElBTkc7QUFPUkMsTUFBQUEsS0FBSyxFQUFFLElBUEM7QUFRUkMsTUFBQUEsS0FBSyxFQUFFLElBUkM7QUFTUkMsTUFBQUEsSUFBSSxFQUFFLElBVEU7QUFVUkMsTUFBQUEsR0FBRyxFQUFFO0FBVkcsS0FBWjtBQUFBLFFBWUFDLFVBWkEsQ0FGSyxDQWNPO0FBRWhCOztBQUNJLFFBQUlDLFNBQVMsR0FBRyxFQUFoQjs7QUFDQSxRQUFHbkIsTUFBTSxDQUFDQyxHQUFQLElBQWMsSUFBakIsRUFBc0I7QUFDbEJELE1BQUFBLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWI7QUFDSCxLQUZELE1BSUlELE1BQU0sQ0FBQ0MsR0FBUCxJQUFjLENBQWQ7O0FBQ0osUUFBSW1CLE1BQU0sR0FBR0MsTUFBTSxDQUFDcEIsR0FBcEI7O0FBRUEsUUFBR0QsTUFBTSxDQUFDQyxHQUFQLEdBQWFtQixNQUFoQixFQUF1QjtBQUNuQnBCLE1BQUFBLE1BQU0sQ0FBQ0MsR0FBUCxHQUFhLENBQWI7QUFDSCxLQTNCSSxDQStCVDs7O0FBQ0EsUUFBSXFCLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUF4QztBQUFBLFFBQ0lDLENBQUMsR0FBR0gsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUR4QztBQUFBLFFBRUlFLENBQUMsR0FBR0osSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUZ4QztBQUFBLFFBR0lHLENBQUMsR0FBR0wsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUh4QztBQUFBLFFBSUlJLENBQUMsR0FBR04sSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUp4QztBQUFBLFFBS0lLLENBQUMsR0FBR1AsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixDQUEzQixJQUFnQyxDQUx4QztBQU1JTSxJQUFBQSxDQUFDLEdBQUcvQixNQUFNLENBQUNDLEdBQVg7QUFDQUMsSUFBQUEsRUFBRSxDQUFDOEIsR0FBSCxDQUFPRCxDQUFQO0FBRUE3QixJQUFBQSxFQUFFLENBQUMrQixJQUFILENBQVEsZ0JBQVIsRUFBMEJDLFlBQTFCLENBQXVDLFlBQXZDLEVBQXFEQyxTQUFyRCxDQUErRGIsQ0FBL0Q7QUFDQXBCLElBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxtQkFBUixFQUE2QkMsWUFBN0IsQ0FBMEMsU0FBMUMsRUFBcURDLFNBQXJELENBQStEVCxDQUEvRDtBQUNBeEIsSUFBQUEsRUFBRSxDQUFDK0IsSUFBSCxDQUFRLGlCQUFSLEVBQTJCQyxZQUEzQixDQUF3QyxZQUF4QyxFQUFzREMsU0FBdEQsQ0FBZ0VSLENBQWhFO0FBQ0F6QixJQUFBQSxFQUFFLENBQUMrQixJQUFILENBQVEsaUJBQVIsRUFBMkJDLFlBQTNCLENBQXdDLFlBQXhDLEVBQXNEQyxTQUF0RCxDQUFnRVAsQ0FBaEU7QUFDQTFCLElBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxvQkFBUixFQUE4QkMsWUFBOUIsQ0FBMkMsWUFBM0MsRUFBeURDLFNBQXpELENBQW1FTixDQUFuRTtBQUNBM0IsSUFBQUEsRUFBRSxDQUFDK0IsSUFBSCxDQUFRLG1CQUFSLEVBQTZCQyxZQUE3QixDQUEwQyxZQUExQyxFQUF3REMsU0FBeEQsQ0FBa0VMLENBQWxFO0FBQ0E1QixJQUFBQSxFQUFFLENBQUMrQixJQUFILENBQVEsWUFBUixFQUFzQkMsWUFBdEIsQ0FBbUMsWUFBbkMsRUFBaURDLFNBQWpELENBQTJESixDQUEzRCxFQS9DSyxDQWdEVDs7QUFDQVosSUFBQUEsU0FBUyxDQUFDaUIsSUFBVixDQUFlZCxDQUFmLEVBQWtCSSxDQUFsQixFQUFxQkMsQ0FBckIsRUFBd0JDLENBQXhCLEVBQTJCQyxDQUEzQixFQUE4QkMsQ0FBOUI7QUFDQVgsSUFBQUEsU0FBUyxDQUFDa0IsSUFBVixHQWxEUyxDQW9EVDs7QUFDQSxRQUFJQyxNQUFNLEdBQUcsQ0FBYjs7QUFFQSxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxVQUFJcEIsU0FBUyxDQUFDb0IsQ0FBRCxDQUFULElBQWdCLENBQXBCLEVBQXVCO0FBQ25CRCxRQUFBQSxNQUFNLEdBQUdBLE1BQU0sR0FBRyxDQUFsQjtBQUNIO0FBQ0osS0EzRFEsQ0E2RFQ7OztBQUNBLFlBQVFBLE1BQVI7QUFDSSxXQUFLLENBQUw7QUFDSSxhQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QztBQUNBLGNBQUlFLFdBQVcsR0FBRyxFQUFsQjs7QUFDQSxlQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd2QixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0UsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxnQkFBSXZCLFNBQVMsQ0FBQ29CLENBQUQsQ0FBVCxJQUFnQnBCLFNBQVMsQ0FBQ3VCLENBQUQsQ0FBN0IsRUFBa0M7QUFDOUJELGNBQUFBLFdBQVcsQ0FBQ0wsSUFBWixDQUFpQmpCLFNBQVMsQ0FBQ3VCLENBQUQsQ0FBMUI7QUFDSDtBQUNKO0FBQ0osU0FUTCxDQVVJOzs7QUFDQSxZQUFJRCxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUJ0QixVQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ08sS0FBbkIsQ0FEMEIsQ0FDQTs7QUFDMUJaLFVBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFNBSkQsTUFJTyxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakN0QixVQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0csS0FBbkIsQ0FEaUMsQ0FDUDs7QUFDMUJSLFVBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFNBSk0sTUFJQSxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakN0QixVQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0UsR0FBbkIsQ0FEaUMsQ0FDVDs7QUFDeEJQLFVBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFNBSk0sTUFJQTtBQUNIO0FBQ0EsY0FBSVEsaUJBQWlCLEdBQUcsS0FBeEI7QUFDQSxjQUFJQyxLQUFLLEdBQUd6QixTQUFaO0FBQ0EsY0FBSTBCLFVBQVUsR0FBR0QsS0FBSyxDQUFDSixNQUF2Qjs7QUFDQSxlQUFLLElBQUlELENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdNLFVBQXBCLEVBQWdDTixDQUFDLEVBQWpDLEVBQXFDO0FBQ2pDLGdCQUFJTyxVQUFVLEdBQUdDLE1BQU0sQ0FBQ0gsS0FBSyxDQUFDTCxDQUFELENBQU4sQ0FBTixHQUFtQixDQUFwQztBQUNBLGdCQUFJUyxPQUFPLEdBQUdELE1BQU0sQ0FBQ0gsS0FBSyxDQUFDTCxDQUFDLEdBQUcsQ0FBTCxDQUFOLENBQXBCOztBQUNBLGdCQUFJQSxDQUFDLEdBQUcsQ0FBSixJQUFTTSxVQUFiLEVBQXlCO0FBQ3JCQyxjQUFBQSxVQUFVLEdBQUdDLE1BQU0sQ0FBQ0gsS0FBSyxDQUFDTCxDQUFELENBQU4sQ0FBbkI7QUFDQVMsY0FBQUEsT0FBTyxHQUFHRCxNQUFNLENBQUNILEtBQUssQ0FBQ0wsQ0FBRCxDQUFOLENBQWhCO0FBQ0g7O0FBQ0QsZ0JBQUlPLFVBQVUsSUFBSUUsT0FBbEIsRUFBMkI7QUFDdkJMLGNBQUFBLGlCQUFpQixHQUFHLEtBQXBCO0FBQ0E7QUFDSCxhQUhELE1BR087QUFDSEEsY0FBQUEsaUJBQWlCLEdBQUcsSUFBcEI7QUFDSDtBQUNKOztBQUNELGNBQUlBLGlCQUFKLEVBQXVCO0FBQ25CekIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNLLElBQW5CO0FBQ0FWLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSkQsTUFJTztBQUNIakIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNTLElBQW5CO0FBQ0FkLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNIO0FBQ0o7O0FBQUE7QUFDRDs7QUFDSixXQUFLLENBQUw7QUFDSSxhQUFLLElBQUlJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxjQUFJRSxXQUFXLEdBQUcsRUFBbEI7O0FBQ0EsZUFBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkIsU0FBUyxDQUFDcUIsTUFBOUIsRUFBc0NFLENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsZ0JBQUl2QixTQUFTLENBQUNvQixDQUFELENBQVQsSUFBZ0JwQixTQUFTLENBQUN1QixDQUFELENBQTdCLEVBQWtDO0FBQzlCRCxjQUFBQSxXQUFXLENBQUNMLElBQVosQ0FBaUJqQixTQUFTLENBQUN1QixDQUFELENBQTFCO0FBQ0g7QUFDSixXQU5zQyxDQU92Qzs7O0FBQ0EsY0FBSUQsV0FBVyxDQUFDRCxNQUFaLEtBQXVCLENBQTNCLEVBQThCO0FBQzFCdEIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNPLEtBQW5CO0FBQ0FaLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSkQsTUFJTztBQUNIakIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNRLEtBQW5CO0FBQ0FiLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDSDtBQUNKOztBQUFBO0FBQ0Q7O0FBQ0osV0FBSyxDQUFMO0FBQ0lqQixRQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ00sR0FBbkI7QUFDQVgsUUFBQUEsRUFBRSxDQUFDK0IsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBOztBQUNKLFdBQUssQ0FBTDtBQUNJO0FBQ0EsWUFBSTNCLEdBQUcsR0FBRyxDQUFWOztBQUNBLGFBQUssSUFBSStCLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxjQUFJcEIsU0FBUyxDQUFDb0IsQ0FBRCxDQUFULEtBQWlCLENBQXJCLEVBQXdCO0FBQ3BCL0IsWUFBQUEsR0FBRyxHQUFHQSxHQUFHLEdBQUcsQ0FBWjtBQUNIO0FBQ0o7O0FBQ0QsWUFBSUEsR0FBRyxJQUFJLENBQVgsRUFBYztBQUNWVSxVQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0MsR0FBbkIsQ0FEVSxDQUNjOztBQUN4Qk4sVUFBQUEsRUFBRSxDQUFDK0IsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNILFNBSEQsTUFHTztBQUNIakIsVUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNJLElBQW5CLENBREcsQ0FDc0I7O0FBQ3pCVCxVQUFBQSxFQUFFLENBQUMrQixJQUFILENBQVEsZUFBUixFQUF5QkMsWUFBekIsQ0FBc0MsWUFBdEMsRUFBb0RDLFNBQXBELENBQThELENBQTlEO0FBQ0g7O0FBQ0Q7O0FBQ0osV0FBSyxDQUFMO0FBQ0lqQixRQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0csS0FBbkIsQ0FESixDQUM4Qjs7QUFDMUJSLFFBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTs7QUFDSixXQUFLLENBQUw7QUFDSWpCLFFBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDRSxHQUFuQixDQURKLENBQzRCOztBQUN4QlAsUUFBQUEsRUFBRSxDQUFDK0IsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBOztBQUNKO0FBQ0k7QUFDQSxhQUFLLElBQUlJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdwQixTQUFTLENBQUNxQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxjQUFJRSxXQUFXLEdBQUcsRUFBbEI7O0FBQ0EsZUFBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkIsU0FBUyxDQUFDcUIsTUFBOUIsRUFBc0NFLENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsZ0JBQUl2QixTQUFTLENBQUNvQixDQUFELENBQVQsSUFBZ0JwQixTQUFTLENBQUN1QixDQUFELENBQTdCLEVBQWtDO0FBQzlCRCxjQUFBQSxXQUFXLENBQUNMLElBQVosQ0FBaUJqQixTQUFTLENBQUN1QixDQUFELENBQTFCO0FBQ0g7QUFDSjs7QUFDRCxjQUFJRCxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUJ0QixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ08sS0FBbkIsQ0FEMEIsQ0FDQTs7QUFDMUJaLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSkQsTUFJTyxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakN0QixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0csS0FBbkIsQ0FEaUMsQ0FDUDs7QUFDMUJSLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSk0sTUFJQSxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakN0QixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0UsR0FBbkIsQ0FEaUMsQ0FDVDs7QUFDeEJQLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSk0sTUFJQTtBQUNIakIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNVLEdBQW5CO0FBQ0FmLFlBQUFBLEVBQUUsQ0FBQytCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDSDtBQUNKOztBQUFBO0FBQ0Q7QUEvSFI7O0FBa0lBakMsSUFBQUEsRUFBRSxDQUFDOEIsR0FBSCxDQUFPZCxVQUFQO0FBQ0M7QUF2TUksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcbndpbmRvdy5UaGVOdW0gPSB7XHJcbiAgICBudW06IG51bGwsXHJcbn07XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgbGV2ZWwgPSB7XHJcbiAgICAgICAgICAgIG9uZTogJ+eKtuWFg+aPkumHkeiKse+8gScsXHJcbiAgICAgICAgICAgIHR3bzogJ+WFree6ouWFreWtkCcsIC8vIOWFreWtkFxyXG4gICAgICAgICAgICB0aHJlZTogJ+S6lOe6ouS6lOWtkCcsIC8vIOS6lOWtkFxyXG4gICAgICAgICAgICBmb3VyOiAn5pmu6YCa54q25YWDJyxcclxuICAgICAgICAgICAgZml2ZTogJ+WvueWggicsXHJcbiAgICAgICAgICAgIHNpeDogJ+S4iee6oicsXHJcbiAgICAgICAgICAgIHNldmVuOiAn5Zub6L+bJyxcclxuICAgICAgICAgICAgZWlnaHQ6ICfkuozkuL4nLFxyXG4gICAgICAgICAgICBuaW5lOiAn5LiA56eAJyxcclxuICAgICAgICAgICAgdGVuOiAn5rKh5pyJ5aWW5ZOm5Lqyfn5+fn4nXHJcbiAgICAgICAgfSxcclxuICAgICAgICB0aGlzX2xldmVsOyAvLyDlrZjlgqjlvZPliY3nrYnnuqdcclxuICAgIFxyXG4gICAgLy8gIOWtmOWCqOW9k+WJjemaj+acuuaVsOe7hFxyXG4gICAgICAgIHZhciBOdW1iZXJBcnIgPSBbXTtcclxuICAgICAgICBpZihUaGVOdW0ubnVtID09IG51bGwpe1xyXG4gICAgICAgICAgICBUaGVOdW0ubnVtID0gMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBcclxuICAgICAgICAgICAgVGhlTnVtLm51bSArPSAxO1xyXG4gICAgICAgIHZhciBudW1NYXggPSBtZW1iZXIubnVtO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmKFRoZU51bS5udW0gPiBudW1NYXgpe1xyXG4gICAgICAgICAgICBUaGVOdW0ubnVtID0gMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcblxyXG5cclxuICAgIC8vICDnlJ/miJDpmo/mnLrmlbDmja5cclxuICAgIHZhciBhID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNikgKyAxLFxyXG4gICAgICAgIGIgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA2KSArIDEsXHJcbiAgICAgICAgYyA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDYpICsgMSxcclxuICAgICAgICBkID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNikgKyAxLFxyXG4gICAgICAgIGUgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA2KSArIDEsXHJcbiAgICAgICAgZiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDYpICsgMTtcclxuICAgICAgICBnID0gVGhlTnVtLm51bTtcclxuICAgICAgICBjYy5sb2coZyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xsaW5nXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKGEpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sbGluZ3R3b1wiKS5nZXRDb21wb25lbnQoXCJ0dXJudHdvXCIpLnNldF92YWx1ZShiKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3JvbGxpbmd0XCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKGMpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sbGluZ2ZcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoZCk7XHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xsaW5nZml2ZVwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZShlKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3JvbGxpbmdzaXhcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoZik7XHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy93aG9cIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoZyk7XHJcbiAgICAvLyDmlbDmja7ov5vlhaXmlbDnu4TvvIzmjpLluo9cclxuICAgIE51bWJlckFyci5wdXNoKGEsIGIsIGMsIGQsIGUsIGYpO1xyXG4gICAgTnVtYmVyQXJyLnNvcnQoKTtcclxuICAgIFxyXG4gICAgLy/lrZjlgqjlvZPliY0g4oCc5Zub4oCdIOeahOS4quaVsFxyXG4gICAgdmFyIGlzZm91ciA9IDA7XHJcbiAgICBcclxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgTnVtYmVyQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgaWYgKE51bWJlckFycltpXSA9PSA0KSB7XHJcbiAgICAgICAgICAgIGlzZm91ciA9IGlzZm91ciArIDE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyDliKTmlq0g4oCc5Zub4oCdIOeahOS4quaVsOWxnuS6juWTquS4gOetiee6pztcclxuICAgIHN3aXRjaCAoaXNmb3VyKSB7XHJcbiAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IE51bWJlckFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgLy/lrZjlgqjlvZPliY3nm7jlkIznmoTmlbDph4/vvIzliKTmlq3mmK/lkKbkuLrlm5vov5tcclxuICAgICAgICAgICAgICAgIHZhciBDb250cmFzdEFyciA9IFtdO1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBOdW1iZXJBcnIubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoTnVtYmVyQXJyW2ldID09IE51bWJlckFycltqXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb250cmFzdEFyci5wdXNoKE51bWJlckFycltqXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIOetieWIsOS4iumdoumBjeWOhuaJp+ihjOWujOWGjei/m+ihjOWIpOaWreWxnuS6juWTquS4que6p+WIq1xyXG4gICAgICAgICAgICBpZiAoQ29udHJhc3RBcnIubGVuZ3RoID09PSA0KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwuc2V2ZW47IC8v5Zub6L+bXHJcbiAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSg0KTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKENvbnRyYXN0QXJyLmxlbmd0aCA9PT0gNSkge1xyXG4gICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnRocmVlOyAvL+S6lOe6olxyXG4gICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChDb250cmFzdEFyci5sZW5ndGggPT09IDYpIHtcclxuICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50d287IC8v5YWt57qiXHJcbiAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSgxKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8g5Yik5pat5LiA5LiL77yM5pivIFwi5a+55aCCXCJcIiBvciDigJ3kuIDnp4DigJzvvIzlr7nloILlsLHmmK/pobrlrZDvvIwxMjM0NTbvvIzkuIDnp4DlsLHmmK/kuIDkuKrlj6rmnIk077ybXHJcbiAgICAgICAgICAgICAgICB2YXIgaXNDb250aW51aXR5QXJyYXkgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHZhciBhcnJheSA9IE51bWJlckFycjtcclxuICAgICAgICAgICAgICAgIHZhciBhcnJheUNvdW50ID0gYXJyYXkubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnJheUNvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY3VycmVudEFyciA9IE51bWJlcihhcnJheVtpXSkgKyAxO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBuZXN0QXJyID0gTnVtYmVyKGFycmF5W2kgKyAxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgKyAxID09IGFycmF5Q291bnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudEFyciA9IE51bWJlcihhcnJheVtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5lc3RBcnIgPSBOdW1iZXIoYXJyYXlbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudEFyciAhPSBuZXN0QXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29udGludWl0eUFycmF5ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29udGludWl0eUFycmF5ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoaXNDb250aW51aXR5QXJyYXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwuZml2ZTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSgyKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLm5pbmU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoNik7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBOdW1iZXJBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIHZhciBDb250cmFzdEFyciA9IFtdO1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBOdW1iZXJBcnIubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoTnVtYmVyQXJyW2ldID09IE51bWJlckFycltqXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb250cmFzdEFyci5wdXNoKE51bWJlckFycltqXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8g5Yik5pat5pivIDTov5sgb3Ig5LqM5Li+XHJcbiAgICAgICAgICAgICAgICBpZiAoQ29udHJhc3RBcnIubGVuZ3RoID09PSA0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnNldmVuO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwuZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoNSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnNpeDtcclxuICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMyk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgNDpcclxuICAgICAgICAgICAgLy8g5Yik5pat5pivIFwi5pmu6YCa54q25YWDXCIgb3IgXCLnirblhYPmj5Lph5HoirFcIu+8jOaZrumAmuWwseaYrzTkuKrlm5vvvIzmj5Lph5HoirHlsLHmmK8gIDTkuKrlm5sgKyAy5LiqMSDvvJtcclxuICAgICAgICAgICAgdmFyIG9uZSA9IDA7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgTnVtYmVyQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTnVtYmVyQXJyW2ldID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb25lID0gb25lICsgMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAob25lID09IDIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC5vbmU7IC8vIOaPkumHkeiKsVxyXG4gICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwuZm91cjsgLy/mma7pgJrnirblhYNcclxuICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnRocmVlOyAvLyDkupTnuqLkupTlrZBcclxuICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgNjpcclxuICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnR3bzsgLy/lha3nuqLlha3lrZBcclxuICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIC8vIOWwseaYr+mhtemdoumDveayoeacieWbmyzmnaXliKTmlq3mmK/lkKblsZ7kuo4g4oCc5LqU5a2Q4oCdIOWSjCDigJzlha3lrZDigJ0g5ZKMIOKAnOWbm+i/m+KAnSDkuK3nmoTlk6rkuIDnp407XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgTnVtYmVyQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgQ29udHJhc3RBcnIgPSBbXTtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgTnVtYmVyQXJyLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlckFycltpXSA9PSBOdW1iZXJBcnJbal0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29udHJhc3RBcnIucHVzaChOdW1iZXJBcnJbal0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChDb250cmFzdEFyci5sZW5ndGggPT09IDQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwuc2V2ZW47IC8v5Zub6L+bXHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoNCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKENvbnRyYXN0QXJyLmxlbmd0aCA9PT0gNSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50aHJlZTsgLy/kupTlrZBcclxuICAgICAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoQ29udHJhc3RBcnIubGVuZ3RoID09PSA2KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnR3bzsgLy/lha3lrZBcclxuICAgICAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnRlbjtcclxuICAgICAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSg3KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgY2MubG9nKHRoaXNfbGV2ZWwpO1xyXG4gICAgfSxcclxuXHJcbiBcclxufSk7XHJcblxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/totouzi.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6c021q5GrJK8acBalebgM3/', 'totouzi');
// scripts/totouzi.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  tomove: function tomove() {
    cc.director.loadScene("touzi");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdG90b3V6aS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsInRvbW92ZSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLE1BUEssb0JBT0ssQ0FBRSxDQVBQO0FBUUxDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVTtBQUNiTCxJQUFBQSxFQUFFLENBQUNNLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixPQUF0QjtBQUNILEdBVkk7QUFXTEMsRUFBQUEsS0FYSyxtQkFXSSxDQUVSLENBYkksQ0FlTDs7QUFmSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQgKCkge30sXHJcbiAgICB0b21vdmU6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJ0b3V6aVwiKVxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/turnall.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a88c2ArEUFKe6Ri6lyLW03h', 'turnall');
// scripts/turnall.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {
    var level = {
      one: '状元插金花！',
      two: '六红六子',
      // 六子
      three: '五红五子',
      // 五子
      four: '普通状元',
      five: '对堂',
      six: '三红',
      seven: '四进',
      eight: '二举',
      nine: '一秀',
      ten: '没有奖哦亲~~~~~'
    },
        this_level; // 存储当前等级
    //  存储当前随机数组

    var NumberArr = []; //  生成随机数据

    var a = Math.floor(Math.random() * 6) + 1,
        b = Math.floor(Math.random() * 6) + 1,
        c = Math.floor(Math.random() * 6) + 1,
        d = Math.floor(Math.random() * 6) + 1,
        e = Math.floor(Math.random() * 6) + 1,
        f = Math.floor(Math.random() * 6) + 1;
    cc.find("Canvas/rolling").getComponent("turnaround").set_value(a);
    cc.find("Canvas/rollingtwo").getComponent("turntwo").set_value(b);
    cc.find("Canvas/rollingt").getComponent("turnaround").set_value(c);
    cc.find("Canvas/rollingf").getComponent("turnaround").set_value(d);
    cc.find("Canvas/rollingfive").getComponent("turnaround").set_value(e);
    cc.find("Canvas/rollingsix").getComponent("turnaround").set_value(f); // 数据进入数组，排序

    NumberArr.push(a, b, c, d, e, f);
    NumberArr.sort(); //存储当前 “四” 的个数

    var isfour = 0;

    for (var i = 0; i < NumberArr.length; i++) {
      if (NumberArr[i] == 4) {
        isfour = isfour + 1;
      }
    } // 判断 “四” 的个数属于哪一等级;


    switch (isfour) {
      case 1:
        for (var i = 0; i < NumberArr.length; i++) {
          //存储当前相同的数量，判断是否为四进
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          }
        } // 等到上面遍历执行完再进行判断属于哪个级别


        if (ContrastArr.length === 4) {
          this_level = level.seven; //四进

          cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
          break;
        } else if (ContrastArr.length === 5) {
          this_level = level.three; //五红

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
          break;
        } else if (ContrastArr.length === 6) {
          this_level = level.two; //六红

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
          break;
        } else {
          // 判断一下，是 "对堂"" or ”一秀“，对堂就是顺子，123456，一秀就是一个只有4；
          var isContinuityArray = false;
          var array = NumberArr;
          var arrayCount = array.length;

          for (var i = 0; i < arrayCount; i++) {
            var currentArr = Number(array[i]) + 1;
            var nestArr = Number(array[i + 1]);

            if (i + 1 == arrayCount) {
              currentArr = Number(array[i]);
              nestArr = Number(array[i]);
            }

            if (currentArr != nestArr) {
              isContinuityArray = false;
              break;
            } else {
              isContinuityArray = true;
            }
          }

          if (isContinuityArray) {
            this_level = level.five;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(2);
            break;
          } else {
            this_level = level.nine;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(6);
            break;
          }
        }

        ;
        break;

      case 2:
        for (var i = 0; i < NumberArr.length; i++) {
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          } // 判断是 4进 or 二举


          if (ContrastArr.length === 4) {
            this_level = level.seven;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
            break;
          } else {
            this_level = level.eight;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(5);
          }
        }

        ;
        break;

      case 3:
        this_level = level.six;
        cc.find("Canvas/answer").getComponent("turnaround").set_value(3);
        break;

      case 4:
        // 判断是 "普通状元" or "状元插金花"，普通就是4个四，插金花就是  4个四 + 2个1 ；
        var one = 0;

        for (var i = 0; i < NumberArr.length; i++) {
          if (NumberArr[i] === 1) {
            one = one + 1;
          }
        }

        if (one == 2) {
          this_level = level.one; // 插金花

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        } else {
          this_level = level.four; //普通状元

          cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        }

        break;

      case 5:
        this_level = level.three; // 五红五子

        cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        break;

      case 6:
        this_level = level.two; //六红六子

        cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
        break;

      default:
        // 就是页面都没有四,来判断是否属于 “五子” 和 “六子” 和 “四进” 中的哪一种;
        for (var i = 0; i < NumberArr.length; i++) {
          var ContrastArr = [];

          for (var j = 0; j < NumberArr.length; j++) {
            if (NumberArr[i] == NumberArr[j]) {
              ContrastArr.push(NumberArr[j]);
            }
          }

          if (ContrastArr.length === 4) {
            this_level = level.seven; //四进

            cc.find("Canvas/answer").getComponent("turnaround").set_value(4);
            break;
          } else if (ContrastArr.length === 5) {
            this_level = level.three; //五子

            cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
            break;
          } else if (ContrastArr.length === 6) {
            this_level = level.two; //六子

            cc.find("Canvas/answer").getComponent("turnaround").set_value(1);
            break;
          } else {
            this_level = level.ten;
            cc.find("Canvas/answer").getComponent("turnaround").set_value(7);
          }
        }

        ;
        break;
    }

    cc.log(this_level); // // 定时来设置最终显示的骰子图片
    // var timeout = $timeout(function() {
    //     $scope.dice_a = a + '.png';
    //     $scope.dice_b = b + '.png';
    //     $scope.dice_c = c + '.png';
    //     $scope.dice_d = d + '.png';
    //     $scope.dice_e = e + '.png';
    //     $scope.dice_f = f + '.png';
    //     // 设置 title 为显示状态
    //     $scope.titleshow = true;
    //     // 显示 level 当前等级
    //     $scope.title = this_level;
    // }, 2000);
    // //$scope.bobinnumber = NumberArr;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdHVybmFsbC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0IiwibGV2ZWwiLCJvbmUiLCJ0d28iLCJ0aHJlZSIsImZvdXIiLCJmaXZlIiwic2l4Iiwic2V2ZW4iLCJlaWdodCIsIm5pbmUiLCJ0ZW4iLCJ0aGlzX2xldmVsIiwiTnVtYmVyQXJyIiwiYSIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsImIiLCJjIiwiZCIsImUiLCJmIiwiZmluZCIsImdldENvbXBvbmVudCIsInNldF92YWx1ZSIsInB1c2giLCJzb3J0IiwiaXNmb3VyIiwiaSIsImxlbmd0aCIsIkNvbnRyYXN0QXJyIiwiaiIsImlzQ29udGludWl0eUFycmF5IiwiYXJyYXkiLCJhcnJheUNvdW50IiwiY3VycmVudEFyciIsIk51bWJlciIsIm5lc3RBcnIiLCJsb2ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUxDLEVBQUFBLEtBTkssbUJBTUk7QUFDTCxRQUFJQyxLQUFLLEdBQUc7QUFDUkMsTUFBQUEsR0FBRyxFQUFFLFFBREc7QUFFUkMsTUFBQUEsR0FBRyxFQUFFLE1BRkc7QUFFSztBQUNiQyxNQUFBQSxLQUFLLEVBQUUsTUFIQztBQUdPO0FBQ2ZDLE1BQUFBLElBQUksRUFBRSxNQUpFO0FBS1JDLE1BQUFBLElBQUksRUFBRSxJQUxFO0FBTVJDLE1BQUFBLEdBQUcsRUFBRSxJQU5HO0FBT1JDLE1BQUFBLEtBQUssRUFBRSxJQVBDO0FBUVJDLE1BQUFBLEtBQUssRUFBRSxJQVJDO0FBU1JDLE1BQUFBLElBQUksRUFBRSxJQVRFO0FBVVJDLE1BQUFBLEdBQUcsRUFBRTtBQVZHLEtBQVo7QUFBQSxRQVlBQyxVQVpBLENBREssQ0FhTztBQUVoQjs7QUFDQSxRQUFJQyxTQUFTLEdBQUcsRUFBaEIsQ0FoQlMsQ0FrQlQ7O0FBQ0EsUUFBSUMsQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBQXhDO0FBQUEsUUFDSUMsQ0FBQyxHQUFHSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBRHhDO0FBQUEsUUFFSUUsQ0FBQyxHQUFHSixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBRnhDO0FBQUEsUUFHSUcsQ0FBQyxHQUFHTCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBSHhDO0FBQUEsUUFJSUksQ0FBQyxHQUFHTixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBSnhDO0FBQUEsUUFLSUssQ0FBQyxHQUFHUCxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLENBQTNCLElBQWdDLENBTHhDO0FBT0lyQixJQUFBQSxFQUFFLENBQUMyQixJQUFILENBQVEsZ0JBQVIsRUFBMEJDLFlBQTFCLENBQXVDLFlBQXZDLEVBQXFEQyxTQUFyRCxDQUErRFgsQ0FBL0Q7QUFDQWxCLElBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxtQkFBUixFQUE2QkMsWUFBN0IsQ0FBMEMsU0FBMUMsRUFBcURDLFNBQXJELENBQStEUCxDQUEvRDtBQUNBdEIsSUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGlCQUFSLEVBQTJCQyxZQUEzQixDQUF3QyxZQUF4QyxFQUFzREMsU0FBdEQsQ0FBZ0VOLENBQWhFO0FBQ0F2QixJQUFBQSxFQUFFLENBQUMyQixJQUFILENBQVEsaUJBQVIsRUFBMkJDLFlBQTNCLENBQXdDLFlBQXhDLEVBQXNEQyxTQUF0RCxDQUFnRUwsQ0FBaEU7QUFDQXhCLElBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxvQkFBUixFQUE4QkMsWUFBOUIsQ0FBMkMsWUFBM0MsRUFBeURDLFNBQXpELENBQW1FSixDQUFuRTtBQUNBekIsSUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLG1CQUFSLEVBQTZCQyxZQUE3QixDQUEwQyxZQUExQyxFQUF3REMsU0FBeEQsQ0FBa0VILENBQWxFLEVBL0JLLENBaUNUOztBQUNBVCxJQUFBQSxTQUFTLENBQUNhLElBQVYsQ0FBZVosQ0FBZixFQUFrQkksQ0FBbEIsRUFBcUJDLENBQXJCLEVBQXdCQyxDQUF4QixFQUEyQkMsQ0FBM0IsRUFBOEJDLENBQTlCO0FBQ0FULElBQUFBLFNBQVMsQ0FBQ2MsSUFBVixHQW5DUyxDQXFDVDs7QUFDQSxRQUFJQyxNQUFNLEdBQUcsQ0FBYjs7QUFFQSxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdoQixTQUFTLENBQUNpQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxVQUFJaEIsU0FBUyxDQUFDZ0IsQ0FBRCxDQUFULElBQWdCLENBQXBCLEVBQXVCO0FBQ25CRCxRQUFBQSxNQUFNLEdBQUdBLE1BQU0sR0FBRyxDQUFsQjtBQUNIO0FBQ0osS0E1Q1EsQ0E4Q1Q7OztBQUNBLFlBQVFBLE1BQVI7QUFDSSxXQUFLLENBQUw7QUFDSSxhQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdoQixTQUFTLENBQUNpQixNQUE5QixFQUFzQ0QsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QztBQUNBLGNBQUlFLFdBQVcsR0FBRyxFQUFsQjs7QUFDQSxlQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUduQixTQUFTLENBQUNpQixNQUE5QixFQUFzQ0UsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QyxnQkFBSW5CLFNBQVMsQ0FBQ2dCLENBQUQsQ0FBVCxJQUFnQmhCLFNBQVMsQ0FBQ21CLENBQUQsQ0FBN0IsRUFBa0M7QUFDOUJELGNBQUFBLFdBQVcsQ0FBQ0wsSUFBWixDQUFpQmIsU0FBUyxDQUFDbUIsQ0FBRCxDQUExQjtBQUNIO0FBQ0o7QUFDSixTQVRMLENBVUk7OztBQUNBLFlBQUlELFdBQVcsQ0FBQ0QsTUFBWixLQUF1QixDQUEzQixFQUE4QjtBQUMxQmxCLFVBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDTyxLQUFuQixDQUQwQixDQUNBOztBQUMxQlosVUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBO0FBQ0gsU0FKRCxNQUlPLElBQUlNLFdBQVcsQ0FBQ0QsTUFBWixLQUF1QixDQUEzQixFQUE4QjtBQUNqQ2xCLFVBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDRyxLQUFuQixDQURpQyxDQUNQOztBQUMxQlIsVUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBO0FBQ0gsU0FKTSxNQUlBLElBQUlNLFdBQVcsQ0FBQ0QsTUFBWixLQUF1QixDQUEzQixFQUE4QjtBQUNqQ2xCLFVBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDRSxHQUFuQixDQURpQyxDQUNUOztBQUN4QlAsVUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBO0FBQ0gsU0FKTSxNQUlBO0FBQ0g7QUFDQSxjQUFJUSxpQkFBaUIsR0FBRyxLQUF4QjtBQUNBLGNBQUlDLEtBQUssR0FBR3JCLFNBQVo7QUFDQSxjQUFJc0IsVUFBVSxHQUFHRCxLQUFLLENBQUNKLE1BQXZCOztBQUNBLGVBQUssSUFBSUQsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR00sVUFBcEIsRUFBZ0NOLENBQUMsRUFBakMsRUFBcUM7QUFDakMsZ0JBQUlPLFVBQVUsR0FBR0MsTUFBTSxDQUFDSCxLQUFLLENBQUNMLENBQUQsQ0FBTixDQUFOLEdBQW1CLENBQXBDO0FBQ0EsZ0JBQUlTLE9BQU8sR0FBR0QsTUFBTSxDQUFDSCxLQUFLLENBQUNMLENBQUMsR0FBRyxDQUFMLENBQU4sQ0FBcEI7O0FBQ0EsZ0JBQUlBLENBQUMsR0FBRyxDQUFKLElBQVNNLFVBQWIsRUFBeUI7QUFDckJDLGNBQUFBLFVBQVUsR0FBR0MsTUFBTSxDQUFDSCxLQUFLLENBQUNMLENBQUQsQ0FBTixDQUFuQjtBQUNBUyxjQUFBQSxPQUFPLEdBQUdELE1BQU0sQ0FBQ0gsS0FBSyxDQUFDTCxDQUFELENBQU4sQ0FBaEI7QUFDSDs7QUFDRCxnQkFBSU8sVUFBVSxJQUFJRSxPQUFsQixFQUEyQjtBQUN2QkwsY0FBQUEsaUJBQWlCLEdBQUcsS0FBcEI7QUFDQTtBQUNILGFBSEQsTUFHTztBQUNIQSxjQUFBQSxpQkFBaUIsR0FBRyxJQUFwQjtBQUNIO0FBQ0o7O0FBQ0QsY0FBSUEsaUJBQUosRUFBdUI7QUFDbkJyQixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0ssSUFBbkI7QUFDQVYsWUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBO0FBQ0gsV0FKRCxNQUlPO0FBQ0hiLFlBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDUyxJQUFuQjtBQUNBZCxZQUFBQSxFQUFFLENBQUMyQixJQUFILENBQVEsZUFBUixFQUF5QkMsWUFBekIsQ0FBc0MsWUFBdEMsRUFBb0RDLFNBQXBELENBQThELENBQTlEO0FBQ0E7QUFDSDtBQUNKOztBQUFBO0FBQ0Q7O0FBQ0osV0FBSyxDQUFMO0FBQ0ksYUFBSyxJQUFJSSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaEIsU0FBUyxDQUFDaUIsTUFBOUIsRUFBc0NELENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsY0FBSUUsV0FBVyxHQUFHLEVBQWxCOztBQUNBLGVBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR25CLFNBQVMsQ0FBQ2lCLE1BQTlCLEVBQXNDRSxDQUFDLEVBQXZDLEVBQTJDO0FBQ3ZDLGdCQUFJbkIsU0FBUyxDQUFDZ0IsQ0FBRCxDQUFULElBQWdCaEIsU0FBUyxDQUFDbUIsQ0FBRCxDQUE3QixFQUFrQztBQUM5QkQsY0FBQUEsV0FBVyxDQUFDTCxJQUFaLENBQWlCYixTQUFTLENBQUNtQixDQUFELENBQTFCO0FBQ0g7QUFDSixXQU5zQyxDQU92Qzs7O0FBQ0EsY0FBSUQsV0FBVyxDQUFDRCxNQUFaLEtBQXVCLENBQTNCLEVBQThCO0FBQzFCbEIsWUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNPLEtBQW5CO0FBQ0FaLFlBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSkQsTUFJTztBQUNIYixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ1EsS0FBbkI7QUFDQWIsWUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNIO0FBQ0o7O0FBQUE7QUFDRDs7QUFDSixXQUFLLENBQUw7QUFDSWIsUUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNNLEdBQW5CO0FBQ0FYLFFBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTs7QUFDSixXQUFLLENBQUw7QUFDSTtBQUNBLFlBQUl2QixHQUFHLEdBQUcsQ0FBVjs7QUFDQSxhQUFLLElBQUkyQixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaEIsU0FBUyxDQUFDaUIsTUFBOUIsRUFBc0NELENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsY0FBSWhCLFNBQVMsQ0FBQ2dCLENBQUQsQ0FBVCxLQUFpQixDQUFyQixFQUF3QjtBQUNwQjNCLFlBQUFBLEdBQUcsR0FBR0EsR0FBRyxHQUFHLENBQVo7QUFDSDtBQUNKOztBQUNELFlBQUlBLEdBQUcsSUFBSSxDQUFYLEVBQWM7QUFDVlUsVUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNDLEdBQW5CLENBRFUsQ0FDYzs7QUFDeEJOLFVBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDSCxTQUhELE1BR087QUFDSGIsVUFBQUEsVUFBVSxHQUFHWCxLQUFLLENBQUNJLElBQW5CLENBREcsQ0FDc0I7O0FBQ3pCVCxVQUFBQSxFQUFFLENBQUMyQixJQUFILENBQVEsZUFBUixFQUF5QkMsWUFBekIsQ0FBc0MsWUFBdEMsRUFBb0RDLFNBQXBELENBQThELENBQTlEO0FBQ0g7O0FBQ0Q7O0FBQ0osV0FBSyxDQUFMO0FBQ0liLFFBQUFBLFVBQVUsR0FBR1gsS0FBSyxDQUFDRyxLQUFuQixDQURKLENBQzhCOztBQUMxQlIsUUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNBOztBQUNKLFdBQUssQ0FBTDtBQUNJYixRQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0UsR0FBbkIsQ0FESixDQUM0Qjs7QUFDeEJQLFFBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTs7QUFDSjtBQUNJO0FBQ0EsYUFBSyxJQUFJSSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHaEIsU0FBUyxDQUFDaUIsTUFBOUIsRUFBc0NELENBQUMsRUFBdkMsRUFBMkM7QUFDdkMsY0FBSUUsV0FBVyxHQUFHLEVBQWxCOztBQUNBLGVBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR25CLFNBQVMsQ0FBQ2lCLE1BQTlCLEVBQXNDRSxDQUFDLEVBQXZDLEVBQTJDO0FBQ3ZDLGdCQUFJbkIsU0FBUyxDQUFDZ0IsQ0FBRCxDQUFULElBQWdCaEIsU0FBUyxDQUFDbUIsQ0FBRCxDQUE3QixFQUFrQztBQUM5QkQsY0FBQUEsV0FBVyxDQUFDTCxJQUFaLENBQWlCYixTQUFTLENBQUNtQixDQUFELENBQTFCO0FBQ0g7QUFDSjs7QUFDRCxjQUFJRCxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUJsQixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ08sS0FBbkIsQ0FEMEIsQ0FDQTs7QUFDMUJaLFlBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSkQsTUFJTyxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakNsQixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0csS0FBbkIsQ0FEaUMsQ0FDUDs7QUFDMUJSLFlBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSk0sTUFJQSxJQUFJTSxXQUFXLENBQUNELE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDakNsQixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ0UsR0FBbkIsQ0FEaUMsQ0FDVDs7QUFDeEJQLFlBQUFBLEVBQUUsQ0FBQzJCLElBQUgsQ0FBUSxlQUFSLEVBQXlCQyxZQUF6QixDQUFzQyxZQUF0QyxFQUFvREMsU0FBcEQsQ0FBOEQsQ0FBOUQ7QUFDQTtBQUNILFdBSk0sTUFJQTtBQUNIYixZQUFBQSxVQUFVLEdBQUdYLEtBQUssQ0FBQ1UsR0FBbkI7QUFDQWYsWUFBQUEsRUFBRSxDQUFDMkIsSUFBSCxDQUFRLGVBQVIsRUFBeUJDLFlBQXpCLENBQXNDLFlBQXRDLEVBQW9EQyxTQUFwRCxDQUE4RCxDQUE5RDtBQUNIO0FBQ0o7O0FBQUE7QUFDRDtBQS9IUjs7QUFrSUE3QixJQUFBQSxFQUFFLENBQUMyQyxHQUFILENBQU8zQixVQUFQLEVBakxTLENBbUxUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQztBQXpNSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcblxyXG5cclxuLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cclxuICAgIH0sXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdmFyIGxldmVsID0ge1xyXG4gICAgICAgICAgICBvbmU6ICfnirblhYPmj5Lph5HoirHvvIEnLFxyXG4gICAgICAgICAgICB0d286ICflha3nuqLlha3lrZAnLCAvLyDlha3lrZBcclxuICAgICAgICAgICAgdGhyZWU6ICfkupTnuqLkupTlrZAnLCAvLyDkupTlrZBcclxuICAgICAgICAgICAgZm91cjogJ+aZrumAmueKtuWFgycsXHJcbiAgICAgICAgICAgIGZpdmU6ICflr7nloIInLFxyXG4gICAgICAgICAgICBzaXg6ICfkuInnuqInLFxyXG4gICAgICAgICAgICBzZXZlbjogJ+Wbm+i/mycsXHJcbiAgICAgICAgICAgIGVpZ2h0OiAn5LqM5Li+JyxcclxuICAgICAgICAgICAgbmluZTogJ+S4gOengCcsXHJcbiAgICAgICAgICAgIHRlbjogJ+ayoeacieWlluWTpuS6sn5+fn5+J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGhpc19sZXZlbDsgLy8g5a2Y5YKo5b2T5YmN562J57qnXHJcbiAgICBcclxuICAgIC8vICDlrZjlgqjlvZPliY3pmo/mnLrmlbDnu4RcclxuICAgIHZhciBOdW1iZXJBcnIgPSBbXTtcclxuICAgIFxyXG4gICAgLy8gIOeUn+aIkOmaj+acuuaVsOaNrlxyXG4gICAgdmFyIGEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA2KSArIDEsXHJcbiAgICAgICAgYiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDYpICsgMSxcclxuICAgICAgICBjID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNikgKyAxLFxyXG4gICAgICAgIGQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA2KSArIDEsXHJcbiAgICAgICAgZSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDYpICsgMSxcclxuICAgICAgICBmID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNikgKyAxO1xyXG5cclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3JvbGxpbmdcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoYSk7XHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xsaW5ndHdvXCIpLmdldENvbXBvbmVudChcInR1cm50d29cIikuc2V0X3ZhbHVlKGIpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sbGluZ3RcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoYyk7XHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9yb2xsaW5nZlwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZShkKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3JvbGxpbmdmaXZlXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKGUpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcm9sbGluZ3NpeFwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZShmKTtcclxuICAgIFxyXG4gICAgLy8g5pWw5o2u6L+b5YWl5pWw57uE77yM5o6S5bqPXHJcbiAgICBOdW1iZXJBcnIucHVzaChhLCBiLCBjLCBkLCBlLCBmKTtcclxuICAgIE51bWJlckFyci5zb3J0KCk7XHJcbiAgICBcclxuICAgIC8v5a2Y5YKo5b2T5YmNIOKAnOWbm+KAnSDnmoTkuKrmlbBcclxuICAgIHZhciBpc2ZvdXIgPSAwO1xyXG4gICAgXHJcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IE51bWJlckFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgIGlmIChOdW1iZXJBcnJbaV0gPT0gNCkge1xyXG4gICAgICAgICAgICBpc2ZvdXIgPSBpc2ZvdXIgKyAxO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8g5Yik5patIOKAnOWbm+KAnSDnmoTkuKrmlbDlsZ7kuo7lk6rkuIDnrYnnuqc7XHJcbiAgICBzd2l0Y2ggKGlzZm91cikge1xyXG4gICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBOdW1iZXJBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIC8v5a2Y5YKo5b2T5YmN55u45ZCM55qE5pWw6YeP77yM5Yik5pat5piv5ZCm5Li65Zub6L+bXHJcbiAgICAgICAgICAgICAgICB2YXIgQ29udHJhc3RBcnIgPSBbXTtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgTnVtYmVyQXJyLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlckFycltpXSA9PSBOdW1iZXJBcnJbal0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29udHJhc3RBcnIucHVzaChOdW1iZXJBcnJbal0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyDnrYnliLDkuIrpnaLpgY3ljobmiafooYzlrozlho3ov5vooYzliKTmlq3lsZ7kuo7lk6rkuKrnuqfliKtcclxuICAgICAgICAgICAgaWYgKENvbnRyYXN0QXJyLmxlbmd0aCA9PT0gNCkge1xyXG4gICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnNldmVuOyAvL+Wbm+i/m1xyXG4gICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoNCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChDb250cmFzdEFyci5sZW5ndGggPT09IDUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50aHJlZTsgLy/kupTnuqJcclxuICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDEpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoQ29udHJhc3RBcnIubGVuZ3RoID09PSA2KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwudHdvOyAvL+WFree6olxyXG4gICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIOWIpOaWreS4gOS4i++8jOaYryBcIuWvueWgglwiXCIgb3Ig4oCd5LiA56eA4oCc77yM5a+55aCC5bCx5piv6aG65a2Q77yMMTIzNDU277yM5LiA56eA5bCx5piv5LiA5Liq5Y+q5pyJNO+8m1xyXG4gICAgICAgICAgICAgICAgdmFyIGlzQ29udGludWl0eUFycmF5ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB2YXIgYXJyYXkgPSBOdW1iZXJBcnI7XHJcbiAgICAgICAgICAgICAgICB2YXIgYXJyYXlDb3VudCA9IGFycmF5Lmxlbmd0aDtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyYXlDb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN1cnJlbnRBcnIgPSBOdW1iZXIoYXJyYXlbaV0pICsgMTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbmVzdEFyciA9IE51bWJlcihhcnJheVtpICsgMV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChpICsgMSA9PSBhcnJheUNvdW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRBcnIgPSBOdW1iZXIoYXJyYXlbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXN0QXJyID0gTnVtYmVyKGFycmF5W2ldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRBcnIgIT0gbmVzdEFycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0NvbnRpbnVpdHlBcnJheSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0NvbnRpbnVpdHlBcnJheSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGlzQ29udGludWl0eUFycmF5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLmZpdmU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMik7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC5uaW5lO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDYpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgTnVtYmVyQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgQ29udHJhc3RBcnIgPSBbXTtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgTnVtYmVyQXJyLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlckFycltpXSA9PSBOdW1iZXJBcnJbal0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29udHJhc3RBcnIucHVzaChOdW1iZXJBcnJbal0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIOWIpOaWreaYryA06L+bIG9yIOS6jOS4vlxyXG4gICAgICAgICAgICAgICAgaWYgKENvbnRyYXN0QXJyLmxlbmd0aCA9PT0gNCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC5zZXZlbjtcclxuICAgICAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSg0KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLmVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC5zaXg7XHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDMpO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgIC8vIOWIpOaWreaYryBcIuaZrumAmueKtuWFg1wiIG9yIFwi54q25YWD5o+S6YeR6IqxXCLvvIzmma7pgJrlsLHmmK805Liq5Zub77yM5o+S6YeR6Iqx5bCx5pivICA05Liq5ZubICsgMuS4qjEg77ybXHJcbiAgICAgICAgICAgIHZhciBvbmUgPSAwO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IE51bWJlckFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKE51bWJlckFycltpXSA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uZSA9IG9uZSArIDE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKG9uZSA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwub25lOyAvLyDmj5Lph5HoirFcclxuICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLmZvdXI7IC8v5pmu6YCa54q25YWDXHJcbiAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL2Fuc3dlclwiKS5nZXRDb21wb25lbnQoXCJ0dXJuYXJvdW5kXCIpLnNldF92YWx1ZSgxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50aHJlZTsgLy8g5LqU57qi5LqU5a2QXHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDEpO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50d287IC8v5YWt57qi5YWt5a2QXHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDEpO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAvLyDlsLHmmK/pobXpnaLpg73msqHmnInlm5ss5p2l5Yik5pat5piv5ZCm5bGe5LqOIOKAnOS6lOWtkOKAnSDlkowg4oCc5YWt5a2Q4oCdIOWSjCDigJzlm5vov5vigJ0g5Lit55qE5ZOq5LiA56eNO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IE51bWJlckFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIENvbnRyYXN0QXJyID0gW107XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IE51bWJlckFyci5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChOdW1iZXJBcnJbaV0gPT0gTnVtYmVyQXJyW2pdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbnRyYXN0QXJyLnB1c2goTnVtYmVyQXJyW2pdKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoQ29udHJhc3RBcnIubGVuZ3RoID09PSA0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc19sZXZlbCA9IGxldmVsLnNldmVuOyAvL+Wbm+i/m1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvYW5zd2VyXCIpLmdldENvbXBvbmVudChcInR1cm5hcm91bmRcIikuc2V0X3ZhbHVlKDQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChDb250cmFzdEFyci5sZW5ndGggPT09IDUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzX2xldmVsID0gbGV2ZWwudGhyZWU7IC8v5LqU5a2QXHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKENvbnRyYXN0QXJyLmxlbmd0aCA9PT0gNikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50d287IC8v5YWt5a2QXHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNfbGV2ZWwgPSBsZXZlbC50ZW47XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9hbnN3ZXJcIikuZ2V0Q29tcG9uZW50KFwidHVybmFyb3VuZFwiKS5zZXRfdmFsdWUoNyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG5cclxuICAgIGNjLmxvZyh0aGlzX2xldmVsKTtcclxuICAgIFxyXG4gICAgLy8gLy8g5a6a5pe25p2l6K6+572u5pyA57uI5pi+56S655qE6aqw5a2Q5Zu+54mHXHJcbiAgICAvLyB2YXIgdGltZW91dCA9ICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2EgPSBhICsgJy5wbmcnO1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2IgPSBiICsgJy5wbmcnO1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2MgPSBjICsgJy5wbmcnO1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2QgPSBkICsgJy5wbmcnO1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2UgPSBlICsgJy5wbmcnO1xyXG4gICAgLy8gICAgICRzY29wZS5kaWNlX2YgPSBmICsgJy5wbmcnO1xyXG4gICAgLy8gICAgIC8vIOiuvue9riB0aXRsZSDkuLrmmL7npLrnirbmgIFcclxuICAgIC8vICAgICAkc2NvcGUudGl0bGVzaG93ID0gdHJ1ZTtcclxuICAgIC8vICAgICAvLyDmmL7npLogbGV2ZWwg5b2T5YmN562J57qnXHJcbiAgICAvLyAgICAgJHNjb3BlLnRpdGxlID0gdGhpc19sZXZlbDtcclxuICAgIC8vIH0sIDIwMDApO1xyXG4gICAgXHJcbiAgICAvLyAvLyRzY29wZS5ib2Jpbm51bWJlciA9IE51bWJlckFycjtcclxuXHJcbiAgICB9LFxyXG5cclxuIFxyXG59KTtcclxuXHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/turnaround.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '838e0xuhbRFZIpHyTYveDwT', 'turnaround');
// scripts/turnaround.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    content: {
      type: cc.Node,
      "default": null
    },
    speed: 300
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  // onSetNum({num = 5}){
  //     //获取数字Label的个数
  //     let childCount = this.node_layout.getChildren().length;
  //     //求出单位y值
  //     let unit_y = this.node_layout.height / childCount;
  //     cc.tween(this.node_layout)
  //       .to(0.5, {position: cc.v2(this.node_layout.x, num * unit_y + unit_y / 2)}, {easing: "quadInOut"})
  //       .start();
  //   },
  start: function start() {// this.num_height = this.content.height/12;
    // this.star_y_num = this.num_height * 0.5;
    // this.now_value = 0;
    // this.content.y = this.star_y_num;
    // var NumberArr = [];
    // this.randomNum = 1;
    // var level = {
    //     one: '状元插金花！',
    //     two: '六红六子', // 六子
    //     three: '五红五子', // 五子
    //     four: '普通状元',
    //     five: '对堂',
    //     six: '三红',
    //     seven: '四进',
    //     eight: '二举',
    //     nine: '一秀',
    //     ten: '没有奖哦亲~~~~~'
    // },
    // this_level; // 存储当前等级
    // this.randomNum = Math.floor(Math.random()*6) + 1;
    //this.set_value(1);
    //this.roll_tonum(4);
    //this.roll_tonum(2);
    // this.roll_tonum(6);
    // this.roll_tonum(1);
    //this.roll(2);
    // for(i = 0; i < 6; i++){
    //     var a = Math.floor(Math.random()*6) + 1;
    //     this.roll(a);
    //    // var m = cc.moveTo(1, 0, 50);
    //     //m.easing(cc.easeCubicActionInOut());
    //     NumberArr.push(a);
    // }
    // NumberArr.sort();
    // for(i = 0; i < 6; i++){
    //     cc.log(NumberArr[i]);
    // }
  },
  set_value: function set_value(value) {
    this.num_height = this.content.height / 12;
    this.star_y_num = this.num_height * 0.5;
    this.now_value = 0;
    this.content.y = this.star_y_num;
    this.randomNum = 1;

    if (value > 10 || value < 1) {
      return;
    }

    this.now_value = value;
    this.content.y = this.star_y_num + (this.now_value - 1) * 100;
  },
  roll_tonum: function roll_tonum(value) {
    if (value > 6 || value < 1) return;

    if (value < this.now_value) {
      var x = value; //value += 6;

      var move_s = (this.now_value - x) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.content.y - move_s);
      m.easing(cc.easeCubicActionInOut()); // this.content.runAction(m);
      // this.now_value = value - 6;
      // this.content.y -= 600;
      // var end_func = cc.callFunc(function(){
      //     this.now_value = x;
      //     this.content.y -= 600;
      // }.bind(this))
      // var seq = cc.sequence([m, end_func]);

      this.content.runAction(m);
      this.now_value = x;
    } else {
      var move_s = (value - this.now_value) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.content.y + move_s);
      m.easing(cc.easeCubicActionInOut());
      this.content.runAction(m);
      this.now_value = value;
    }
  },
  playing: function playing(value) {
    cc.log("dddddddddddd");
  },
  roll: function roll(value) {
    if (value > 6 || value < 1) return;
    value += 6;
    var move_s = (value - this.now_value) * 100;
    var time = move_s / this.speed;
    var m = cc.moveTo(time, 0, this.content.y + move_s);
    m.easing(cc.easeCubicActionInOut());
    this.content.runAction(m);
    var end_func = cc.callFunc(function () {
      this.now_value = value - 6;
      this.content.y -= 6 * 100;
    }.bind(this));
    this.content.runAction(end_func); //var seq = cc.sequence([m, end_func]);
    //this.content.runAction(seq);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdHVybmFyb3VuZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvbnRlbnQiLCJ0eXBlIiwiTm9kZSIsInNwZWVkIiwic3RhcnQiLCJzZXRfdmFsdWUiLCJ2YWx1ZSIsIm51bV9oZWlnaHQiLCJoZWlnaHQiLCJzdGFyX3lfbnVtIiwibm93X3ZhbHVlIiwieSIsInJhbmRvbU51bSIsInJvbGxfdG9udW0iLCJ4IiwibW92ZV9zIiwidGltZSIsIm0iLCJtb3ZlVG8iLCJlYXNpbmciLCJlYXNlQ3ViaWNBY3Rpb25Jbk91dCIsInJ1bkFjdGlvbiIsInBsYXlpbmciLCJsb2ciLCJyb2xsIiwiZW5kX2Z1bmMiLCJjYWxsRnVuYyIsImJpbmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxPQUFPLEVBQUM7QUFDSkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBREw7QUFFSixpQkFBUztBQUZMLEtBREE7QUFLUkMsSUFBQUEsS0FBSyxFQUFFO0FBTEMsR0FIUDtBQVdMO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQUMsRUFBQUEsS0F6QkssbUJBeUJJLENBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDQztBQUNBO0FBQ0E7QUFFSCxHQXJFSTtBQXlFTEMsRUFBQUEsU0F6RUsscUJBeUVLQyxLQXpFTCxFQXlFVztBQUNaLFNBQUtDLFVBQUwsR0FBa0IsS0FBS1AsT0FBTCxDQUFhUSxNQUFiLEdBQW9CLEVBQXRDO0FBQ0EsU0FBS0MsVUFBTCxHQUFrQixLQUFLRixVQUFMLEdBQWtCLEdBQXBDO0FBQ0EsU0FBS0csU0FBTCxHQUFpQixDQUFqQjtBQUNBLFNBQUtWLE9BQUwsQ0FBYVcsQ0FBYixHQUFpQixLQUFLRixVQUF0QjtBQUNBLFNBQUtHLFNBQUwsR0FBaUIsQ0FBakI7O0FBSUEsUUFBR04sS0FBSyxHQUFHLEVBQVIsSUFBY0EsS0FBSyxHQUFHLENBQXpCLEVBQTJCO0FBQ3ZCO0FBQ0g7O0FBQ0QsU0FBS0ksU0FBTCxHQUFpQkosS0FBakI7QUFDQSxTQUFLTixPQUFMLENBQWFXLENBQWIsR0FBaUIsS0FBS0YsVUFBTCxHQUFrQixDQUFDLEtBQUtDLFNBQUwsR0FBaUIsQ0FBbEIsSUFBdUIsR0FBMUQ7QUFFSCxHQXhGSTtBQTRGTEcsRUFBQUEsVUE1Rkssc0JBNEZNUCxLQTVGTixFQTRGWTtBQUNiLFFBQUdBLEtBQUssR0FBRyxDQUFSLElBQWFBLEtBQUssR0FBRyxDQUF4QixFQUNJOztBQUNKLFFBQUdBLEtBQUssR0FBRyxLQUFLSSxTQUFoQixFQUEwQjtBQUN0QixVQUFJSSxDQUFDLEdBQUdSLEtBQVIsQ0FEc0IsQ0FFdEI7O0FBQ0EsVUFBSVMsTUFBTSxHQUFHLENBQUMsS0FBS0wsU0FBTCxHQUFpQkksQ0FBbEIsSUFBdUIsS0FBS1AsVUFBekM7QUFDQSxVQUFJUyxJQUFJLEdBQUdELE1BQU0sR0FBQyxLQUFLWixLQUF2QjtBQUNBLFVBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBRUFFLE1BQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVCxFQVBzQixDQVN0QjtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFdBQUtQLFNBQUwsR0FBaUJJLENBQWpCO0FBQ0gsS0FyQkQsTUFzQkk7QUFDQSxVQUFJQyxNQUFNLEdBQUcsQ0FBQ1QsS0FBSyxHQUFHLEtBQUtJLFNBQWQsSUFBMkIsS0FBS0gsVUFBN0M7QUFDQSxVQUFJUyxJQUFJLEdBQUdELE1BQU0sR0FBRyxLQUFLWixLQUF6QjtBQUNBLFVBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBQ0FFLE1BQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVDtBQUNBLFdBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFdBQUtQLFNBQUwsR0FBaUJKLEtBQWpCO0FBQ0g7QUFDSixHQTdISTtBQStITGdCLEVBQUFBLE9BL0hLLG1CQStIR2hCLEtBL0hILEVBK0hTO0FBQ1ZWLElBQUFBLEVBQUUsQ0FBQzJCLEdBQUgsQ0FBTyxjQUFQO0FBQ0gsR0FqSUk7QUFtSUxDLEVBQUFBLElBbklLLGdCQW1JQWxCLEtBbklBLEVBbUlNO0FBQ1AsUUFBR0EsS0FBSyxHQUFHLENBQVIsSUFBYUEsS0FBSyxHQUFHLENBQXhCLEVBQ0k7QUFDQUEsSUFBQUEsS0FBSyxJQUFJLENBQVQ7QUFFQSxRQUFJUyxNQUFNLEdBQUcsQ0FBQ1QsS0FBSyxHQUFHLEtBQUtJLFNBQWQsSUFBMkIsR0FBeEM7QUFDQSxRQUFJTSxJQUFJLEdBQUdELE1BQU0sR0FBQyxLQUFLWixLQUF2QjtBQUNBLFFBQUljLENBQUMsR0FBR3JCLEVBQUUsQ0FBQ3NCLE1BQUgsQ0FBVUYsSUFBVixFQUFnQixDQUFoQixFQUFtQixLQUFLaEIsT0FBTCxDQUFhVyxDQUFiLEdBQWlCSSxNQUFwQyxDQUFSO0FBRUFFLElBQUFBLENBQUMsQ0FBQ0UsTUFBRixDQUFTdkIsRUFBRSxDQUFDd0Isb0JBQUgsRUFBVDtBQUNBLFNBQUtwQixPQUFMLENBQWFxQixTQUFiLENBQXVCSixDQUF2QjtBQUNBLFFBQUlRLFFBQVEsR0FBRzdCLEVBQUUsQ0FBQzhCLFFBQUgsQ0FBWSxZQUFVO0FBQ2pDLFdBQUtoQixTQUFMLEdBQWlCSixLQUFLLEdBQUcsQ0FBekI7QUFDQSxXQUFLTixPQUFMLENBQWFXLENBQWIsSUFBa0IsSUFBSSxHQUF0QjtBQUNILEtBSDBCLENBR3pCZ0IsSUFIeUIsQ0FHcEIsSUFIb0IsQ0FBWixDQUFmO0FBSUEsU0FBSzNCLE9BQUwsQ0FBYXFCLFNBQWIsQ0FBdUJJLFFBQXZCLEVBZkcsQ0FnQkg7QUFDQTtBQUNQLEdBckpJLENBdUpMOztBQXZKSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY29udGVudDp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzcGVlZDogMzAwLCAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG4gICAgLy8gb25TZXROdW0oe251bSA9IDV9KXtcclxuICAgIC8vICAgICAvL+iOt+WPluaVsOWtl0xhYmVs55qE5Liq5pWwXHJcbiAgICAvLyAgICAgbGV0IGNoaWxkQ291bnQgPSB0aGlzLm5vZGVfbGF5b3V0LmdldENoaWxkcmVuKCkubGVuZ3RoO1xyXG4gICAgLy8gICAgIC8v5rGC5Ye65Y2V5L2NeeWAvFxyXG4gICAgLy8gICAgIGxldCB1bml0X3kgPSB0aGlzLm5vZGVfbGF5b3V0LmhlaWdodCAvIGNoaWxkQ291bnQ7XHJcbiAgICBcclxuICAgIC8vICAgICBjYy50d2Vlbih0aGlzLm5vZGVfbGF5b3V0KVxyXG4gICAgLy8gICAgICAgLnRvKDAuNSwge3Bvc2l0aW9uOiBjYy52Mih0aGlzLm5vZGVfbGF5b3V0LngsIG51bSAqIHVuaXRfeSArIHVuaXRfeSAvIDIpfSwge2Vhc2luZzogXCJxdWFkSW5PdXRcIn0pXHJcbiAgICAvLyAgICAgICAuc3RhcnQoKTtcclxuICAgIC8vICAgfSxcclxuICAgIFxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIC8vIHRoaXMubnVtX2hlaWdodCA9IHRoaXMuY29udGVudC5oZWlnaHQvMTI7XHJcbiAgICAgICAgLy8gdGhpcy5zdGFyX3lfbnVtID0gdGhpcy5udW1faGVpZ2h0ICogMC41O1xyXG4gICAgICAgIC8vIHRoaXMubm93X3ZhbHVlID0gMDtcclxuICAgICAgICAvLyB0aGlzLmNvbnRlbnQueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICAvLyB2YXIgTnVtYmVyQXJyID0gW107XHJcbiAgICAgICAgLy8gdGhpcy5yYW5kb21OdW0gPSAxO1xyXG5cclxuXHJcblxyXG4gICAgICAgIC8vIHZhciBsZXZlbCA9IHtcclxuICAgICAgICAvLyAgICAgb25lOiAn54q25YWD5o+S6YeR6Iqx77yBJyxcclxuICAgICAgICAvLyAgICAgdHdvOiAn5YWt57qi5YWt5a2QJywgLy8g5YWt5a2QXHJcbiAgICAgICAgLy8gICAgIHRocmVlOiAn5LqU57qi5LqU5a2QJywgLy8g5LqU5a2QXHJcbiAgICAgICAgLy8gICAgIGZvdXI6ICfmma7pgJrnirblhYMnLFxyXG4gICAgICAgIC8vICAgICBmaXZlOiAn5a+55aCCJyxcclxuICAgICAgICAvLyAgICAgc2l4OiAn5LiJ57qiJyxcclxuICAgICAgICAvLyAgICAgc2V2ZW46ICflm5vov5snLFxyXG4gICAgICAgIC8vICAgICBlaWdodDogJ+S6jOS4vicsXHJcbiAgICAgICAgLy8gICAgIG5pbmU6ICfkuIDnp4AnLFxyXG4gICAgICAgIC8vICAgICB0ZW46ICfmsqHmnInlpZblk6bkurJ+fn5+fidcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIHRoaXNfbGV2ZWw7IC8vIOWtmOWCqOW9k+WJjeetiee6p1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIHRoaXMucmFuZG9tTnVtID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjYpICsgMTtcclxuICAgICAgICAvL3RoaXMuc2V0X3ZhbHVlKDEpO1xyXG5cclxuICAgICAgICAvL3RoaXMucm9sbF90b251bSg0KTtcclxuICAgICAgICAvL3RoaXMucm9sbF90b251bSgyKTtcclxuICAgICAgICAvLyB0aGlzLnJvbGxfdG9udW0oNik7XHJcbiAgICAgICAgLy8gdGhpcy5yb2xsX3RvbnVtKDEpO1xyXG4gICAgICAgIC8vdGhpcy5yb2xsKDIpO1xyXG4gICAgICAgIC8vIGZvcihpID0gMDsgaSA8IDY7IGkrKyl7XHJcbiAgICAgICAgLy8gICAgIHZhciBhID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjYpICsgMTtcclxuICAgICAgICAvLyAgICAgdGhpcy5yb2xsKGEpO1xyXG4gICAgICAgIC8vICAgIC8vIHZhciBtID0gY2MubW92ZVRvKDEsIDAsIDUwKTtcclxuICAgICAgICAvLyAgICAgLy9tLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAvLyAgICAgTnVtYmVyQXJyLnB1c2goYSk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgLy8gTnVtYmVyQXJyLnNvcnQoKTtcclxuICAgICAgICAvLyBmb3IoaSA9IDA7IGkgPCA2OyBpKyspe1xyXG4gICAgICAgIC8vICAgICBjYy5sb2coTnVtYmVyQXJyW2ldKTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBcclxuXHJcbiAgICBzZXRfdmFsdWUodmFsdWUpe1xyXG4gICAgICAgIHRoaXMubnVtX2hlaWdodCA9IHRoaXMuY29udGVudC5oZWlnaHQvMTI7XHJcbiAgICAgICAgdGhpcy5zdGFyX3lfbnVtID0gdGhpcy5udW1faGVpZ2h0ICogMC41O1xyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gMDtcclxuICAgICAgICB0aGlzLmNvbnRlbnQueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICB0aGlzLnJhbmRvbU51bSA9IDE7XHJcblxyXG5cclxuXHJcbiAgICAgICAgaWYodmFsdWUgPiAxMCB8fCB2YWx1ZSA8IDEpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnkgPSB0aGlzLnN0YXJfeV9udW0gKyAodGhpcy5ub3dfdmFsdWUgLSAxKSAqIDEwMDtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICByb2xsX3RvbnVtKHZhbHVlKXtcclxuICAgICAgICBpZih2YWx1ZSA+IDYgfHwgdmFsdWUgPCAxKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYodmFsdWUgPCB0aGlzLm5vd192YWx1ZSl7XHJcbiAgICAgICAgICAgIHZhciB4ID0gdmFsdWU7XHJcbiAgICAgICAgICAgIC8vdmFsdWUgKz0gNjtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh0aGlzLm5vd192YWx1ZSAtIHgpICogdGhpcy5udW1faGVpZ2h0O1xyXG4gICAgICAgICAgICB2YXIgdGltZSA9IG1vdmVfcy90aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSAtIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMuY29udGVudC5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMubm93X3ZhbHVlID0gdmFsdWUgLSA2O1xyXG4gICAgICAgICAgICAvLyB0aGlzLmNvbnRlbnQueSAtPSA2MDA7XHJcblxyXG5cclxuICAgICAgICAgICAgLy8gdmFyIGVuZF9mdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuY29udGVudC55IC09IDYwMDtcclxuICAgICAgICAgICAgLy8gfS5iaW5kKHRoaXMpKVxyXG4gICAgICAgICAgICAvLyB2YXIgc2VxID0gY2Muc2VxdWVuY2UoW20sIGVuZF9mdW5jXSk7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGVudC5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh2YWx1ZSAtIHRoaXMubm93X3ZhbHVlKSAqIHRoaXMubnVtX2hlaWdodDtcclxuICAgICAgICAgICAgdmFyIHRpbWUgPSBtb3ZlX3MgLyB0aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSArIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIG0uZWFzaW5nKGNjLmVhc2VDdWJpY0FjdGlvbkluT3V0KCkpO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQucnVuQWN0aW9uKG0pO1xyXG4gICAgICAgICAgICB0aGlzLm5vd192YWx1ZSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgcGxheWluZyh2YWx1ZSl7XHJcbiAgICAgICAgY2MubG9nKFwiZGRkZGRkZGRkZGRkXCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICByb2xsKHZhbHVlKXtcclxuICAgICAgICBpZih2YWx1ZSA+IDYgfHwgdmFsdWUgPCAxKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIHZhbHVlICs9IDY7XHJcblxyXG4gICAgICAgICAgICB2YXIgbW92ZV9zID0gKHZhbHVlIC0gdGhpcy5ub3dfdmFsdWUpICogMTAwO1xyXG4gICAgICAgICAgICB2YXIgdGltZSA9IG1vdmVfcy90aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnQueSArIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LnJ1bkFjdGlvbihtKTtcclxuICAgICAgICAgICAgdmFyIGVuZF9mdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWUgLSA2O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250ZW50LnkgLT0gNiAqIDEwMDtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKVxyXG4gICAgICAgICAgICB0aGlzLmNvbnRlbnQucnVuQWN0aW9uKGVuZF9mdW5jKTtcclxuICAgICAgICAgICAgLy92YXIgc2VxID0gY2Muc2VxdWVuY2UoW20sIGVuZF9mdW5jXSk7XHJcbiAgICAgICAgICAgIC8vdGhpcy5jb250ZW50LnJ1bkFjdGlvbihzZXEpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/count.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8cbc4AL5DpC0rIcQElHZCDY', 'count');
// scripts/count.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  count: function count() {
    cc.find("Canvas").getComponent("numing").gainScore();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY291bnQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydCIsImNvdW50IiwiZmluZCIsImdldENvbXBvbmVudCIsImdhaW5TY29yZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLENBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlEsR0FIUDtBQXFCTDtBQUVBO0FBRUFDLEVBQUFBLEtBekJLLG1CQXlCSSxDQUVSLENBM0JJO0FBNEJMQyxFQUFBQSxLQTVCSyxtQkE0QkU7QUFDSEwsSUFBQUEsRUFBRSxDQUFDTSxJQUFILENBQVEsUUFBUixFQUFrQkMsWUFBbEIsQ0FBK0IsUUFBL0IsRUFBeUNDLFNBQXpDO0FBQ0gsR0E5QkksQ0ErQkw7O0FBL0JLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG4gICAgY291bnQoKXtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzXCIpLmdldENvbXBvbmVudChcIm51bWluZ1wiKS5nYWluU2NvcmUoKTtcclxuICAgIH0sXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/turntwo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b18a4tL1RhIjo25nLHNkuG7', 'turntwo');
// scripts/turntwo.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    contentc: {
      type: cc.Node,
      "default": null
    },
    speed: 300
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  // onSetNum({num = 5}){
  //     //获取数字Label的个数
  //     let childCount = this.node_layout.getChildren().length;
  //     //求出单位y值
  //     let unit_y = this.node_layout.height / childCount;
  //     cc.tween(this.node_layout)
  //       .to(0.5, {position: cc.v2(this.node_layout.x, num * unit_y + unit_y / 2)}, {easing: "quadInOut"})
  //       .start();
  //   },
  start: function start() {// var level = {
    //     one: '状元插金花！',
    //     two: '六红六子', // 六子
    //     three: '五红五子', // 五子
    //     four: '普通状元',
    //     five: '对堂',
    //     six: '三红',
    //     seven: '四进',
    //     eight: '二举',
    //     nine: '一秀',
    //     ten: '没有奖哦亲~~~~~'
    // },
    // this_level; // 存储当前等级
    // this.randomNum = Math.floor(Math.random()*6) + 1;
    //this.set_value(1);
    //this.roll_tonum(3);
  },
  set_value: function set_value(value) {
    this.num_height = this.contentc.height / 12;
    this.star_y_num = this.num_height * 0.5;
    this.now_value = 0;
    this.contentc.y = this.star_y_num;
    this.randomNum = 1;

    if (value > 6 || value < 1) {
      return;
    }

    this.now_value = value;
    this.contentc.y = this.star_y_num + (this.now_value - 1) * 100;
  },
  roll_tonum: function roll_tonum(value) {
    if (value > 10 || value < 1) return;

    if (value < this.now_value) {
      var x = value; //value += 6;

      var move_s = (this.now_value - x) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.contentc.y - move_s);
      m.easing(cc.easeCubicActionInOut());
      this.contentc.runAction(m);
      this.now_value = x;
    } else {
      var move_s = (value - this.now_value) * this.num_height;
      var time = move_s / this.speed;
      var m = cc.moveTo(time, 0, this.contentc.y + move_s);
      m.easing(cc.easeCubicActionInOut());
      this.contentc.runAction(m);
      this.now_value = value;
    }
  },
  playing: function playing() {
    cc.log("dddddd");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdHVybnR3by5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvbnRlbnRjIiwidHlwZSIsIk5vZGUiLCJzcGVlZCIsInN0YXJ0Iiwic2V0X3ZhbHVlIiwidmFsdWUiLCJudW1faGVpZ2h0IiwiaGVpZ2h0Iiwic3Rhcl95X251bSIsIm5vd192YWx1ZSIsInkiLCJyYW5kb21OdW0iLCJyb2xsX3RvbnVtIiwieCIsIm1vdmVfcyIsInRpbWUiLCJtIiwibW92ZVRvIiwiZWFzaW5nIiwiZWFzZUN1YmljQWN0aW9uSW5PdXQiLCJydW5BY3Rpb24iLCJwbGF5aW5nIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsUUFBUSxFQUFDO0FBQ0xDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURKO0FBRUwsaUJBQVM7QUFGSixLQUREO0FBS1JDLElBQUFBLEtBQUssRUFBRTtBQUxDLEdBSFA7QUFXTDtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUFDLEVBQUFBLEtBekJLLG1CQXlCSSxDQUVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBR0gsR0EvQ0k7QUFtRExDLEVBQUFBLFNBbkRLLHFCQW1ES0MsS0FuREwsRUFtRFc7QUFDWixTQUFLQyxVQUFMLEdBQWtCLEtBQUtQLFFBQUwsQ0FBY1EsTUFBZCxHQUFxQixFQUF2QztBQUNBLFNBQUtDLFVBQUwsR0FBa0IsS0FBS0YsVUFBTCxHQUFrQixHQUFwQztBQUNBLFNBQUtHLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSxTQUFLVixRQUFMLENBQWNXLENBQWQsR0FBa0IsS0FBS0YsVUFBdkI7QUFDQSxTQUFLRyxTQUFMLEdBQWlCLENBQWpCOztBQUVBLFFBQUdOLEtBQUssR0FBRyxDQUFSLElBQWFBLEtBQUssR0FBRyxDQUF4QixFQUEwQjtBQUN0QjtBQUNIOztBQUNELFNBQUtJLFNBQUwsR0FBaUJKLEtBQWpCO0FBQ0EsU0FBS04sUUFBTCxDQUFjVyxDQUFkLEdBQWtCLEtBQUtGLFVBQUwsR0FBa0IsQ0FBQyxLQUFLQyxTQUFMLEdBQWlCLENBQWxCLElBQXVCLEdBQTNEO0FBRUgsR0FoRUk7QUFvRUxHLEVBQUFBLFVBcEVLLHNCQW9FTVAsS0FwRU4sRUFvRVk7QUFDYixRQUFHQSxLQUFLLEdBQUcsRUFBUixJQUFjQSxLQUFLLEdBQUcsQ0FBekIsRUFDSTs7QUFDSixRQUFHQSxLQUFLLEdBQUcsS0FBS0ksU0FBaEIsRUFBMEI7QUFDdEIsVUFBSUksQ0FBQyxHQUFHUixLQUFSLENBRHNCLENBRXRCOztBQUNBLFVBQUlTLE1BQU0sR0FBRyxDQUFDLEtBQUtMLFNBQUwsR0FBaUJJLENBQWxCLElBQXVCLEtBQUtQLFVBQXpDO0FBQ0EsVUFBSVMsSUFBSSxHQUFHRCxNQUFNLEdBQUMsS0FBS1osS0FBdkI7QUFDQSxVQUFJYyxDQUFDLEdBQUdyQixFQUFFLENBQUNzQixNQUFILENBQVVGLElBQVYsRUFBZ0IsQ0FBaEIsRUFBbUIsS0FBS2hCLFFBQUwsQ0FBY1csQ0FBZCxHQUFrQkksTUFBckMsQ0FBUjtBQUVBRSxNQUFBQSxDQUFDLENBQUNFLE1BQUYsQ0FBU3ZCLEVBQUUsQ0FBQ3dCLG9CQUFILEVBQVQ7QUFDQSxXQUFLcEIsUUFBTCxDQUFjcUIsU0FBZCxDQUF3QkosQ0FBeEI7QUFDQSxXQUFLUCxTQUFMLEdBQWlCSSxDQUFqQjtBQUNILEtBVkQsTUFXSTtBQUNBLFVBQUlDLE1BQU0sR0FBRyxDQUFDVCxLQUFLLEdBQUcsS0FBS0ksU0FBZCxJQUEyQixLQUFLSCxVQUE3QztBQUNBLFVBQUlTLElBQUksR0FBR0QsTUFBTSxHQUFHLEtBQUtaLEtBQXpCO0FBQ0EsVUFBSWMsQ0FBQyxHQUFHckIsRUFBRSxDQUFDc0IsTUFBSCxDQUFVRixJQUFWLEVBQWdCLENBQWhCLEVBQW1CLEtBQUtoQixRQUFMLENBQWNXLENBQWQsR0FBa0JJLE1BQXJDLENBQVI7QUFDQUUsTUFBQUEsQ0FBQyxDQUFDRSxNQUFGLENBQVN2QixFQUFFLENBQUN3QixvQkFBSCxFQUFUO0FBQ0EsV0FBS3BCLFFBQUwsQ0FBY3FCLFNBQWQsQ0FBd0JKLENBQXhCO0FBQ0EsV0FBS1AsU0FBTCxHQUFpQkosS0FBakI7QUFDSDtBQUNKLEdBMUZJO0FBNEZMZ0IsRUFBQUEsT0E1RksscUJBNEZJO0FBQ0wxQixJQUFBQSxFQUFFLENBQUMyQixHQUFILENBQU8sUUFBUDtBQUNILEdBOUZJLENBaUdMOztBQWpHSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY29udGVudGM6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3BlZWQ6IDMwMCwgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuICAgIC8vIG9uU2V0TnVtKHtudW0gPSA1fSl7XHJcbiAgICAvLyAgICAgLy/ojrflj5bmlbDlrZdMYWJlbOeahOS4quaVsFxyXG4gICAgLy8gICAgIGxldCBjaGlsZENvdW50ID0gdGhpcy5ub2RlX2xheW91dC5nZXRDaGlsZHJlbigpLmxlbmd0aDtcclxuICAgIC8vICAgICAvL+axguWHuuWNleS9jXnlgLxcclxuICAgIC8vICAgICBsZXQgdW5pdF95ID0gdGhpcy5ub2RlX2xheW91dC5oZWlnaHQgLyBjaGlsZENvdW50O1xyXG4gICAgXHJcbiAgICAvLyAgICAgY2MudHdlZW4odGhpcy5ub2RlX2xheW91dClcclxuICAgIC8vICAgICAgIC50bygwLjUsIHtwb3NpdGlvbjogY2MudjIodGhpcy5ub2RlX2xheW91dC54LCBudW0gKiB1bml0X3kgKyB1bml0X3kgLyAyKX0sIHtlYXNpbmc6IFwicXVhZEluT3V0XCJ9KVxyXG4gICAgLy8gICAgICAgLnN0YXJ0KCk7XHJcbiAgICAvLyAgIH0sXHJcbiAgICBcclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBcclxuICAgICAgICAvLyB2YXIgbGV2ZWwgPSB7XHJcbiAgICAgICAgLy8gICAgIG9uZTogJ+eKtuWFg+aPkumHkeiKse+8gScsXHJcbiAgICAgICAgLy8gICAgIHR3bzogJ+WFree6ouWFreWtkCcsIC8vIOWFreWtkFxyXG4gICAgICAgIC8vICAgICB0aHJlZTogJ+S6lOe6ouS6lOWtkCcsIC8vIOS6lOWtkFxyXG4gICAgICAgIC8vICAgICBmb3VyOiAn5pmu6YCa54q25YWDJyxcclxuICAgICAgICAvLyAgICAgZml2ZTogJ+WvueWggicsXHJcbiAgICAgICAgLy8gICAgIHNpeDogJ+S4iee6oicsXHJcbiAgICAgICAgLy8gICAgIHNldmVuOiAn5Zub6L+bJyxcclxuICAgICAgICAvLyAgICAgZWlnaHQ6ICfkuozkuL4nLFxyXG4gICAgICAgIC8vICAgICBuaW5lOiAn5LiA56eAJyxcclxuICAgICAgICAvLyAgICAgdGVuOiAn5rKh5pyJ5aWW5ZOm5Lqyfn5+fn4nXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyB0aGlzX2xldmVsOyAvLyDlrZjlgqjlvZPliY3nrYnnuqdcclxuICAgICAgICBcclxuICAgICAgICAvLyB0aGlzLnJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSo2KSArIDE7XHJcbiAgICAgICAgLy90aGlzLnNldF92YWx1ZSgxKTtcclxuXHJcbiAgICAgICAgLy90aGlzLnJvbGxfdG9udW0oMyk7XHJcblxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgXHJcblxyXG4gICAgc2V0X3ZhbHVlKHZhbHVlKXtcclxuICAgICAgICB0aGlzLm51bV9oZWlnaHQgPSB0aGlzLmNvbnRlbnRjLmhlaWdodC8xMjtcclxuICAgICAgICB0aGlzLnN0YXJfeV9udW0gPSB0aGlzLm51bV9oZWlnaHQgKiAwLjU7XHJcbiAgICAgICAgdGhpcy5ub3dfdmFsdWUgPSAwO1xyXG4gICAgICAgIHRoaXMuY29udGVudGMueSA9IHRoaXMuc3Rhcl95X251bTtcclxuICAgICAgICB0aGlzLnJhbmRvbU51bSA9IDE7XHJcblxyXG4gICAgICAgIGlmKHZhbHVlID4gNiB8fCB2YWx1ZSA8IDEpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgdGhpcy5jb250ZW50Yy55ID0gdGhpcy5zdGFyX3lfbnVtICsgKHRoaXMubm93X3ZhbHVlIC0gMSkgKiAxMDA7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgcm9sbF90b251bSh2YWx1ZSl7XHJcbiAgICAgICAgaWYodmFsdWUgPiAxMCB8fCB2YWx1ZSA8IDEpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBpZih2YWx1ZSA8IHRoaXMubm93X3ZhbHVlKXtcclxuICAgICAgICAgICAgdmFyIHggPSB2YWx1ZTtcclxuICAgICAgICAgICAgLy92YWx1ZSArPSA2O1xyXG4gICAgICAgICAgICB2YXIgbW92ZV9zID0gKHRoaXMubm93X3ZhbHVlIC0geCkgKiB0aGlzLm51bV9oZWlnaHQ7XHJcbiAgICAgICAgICAgIHZhciB0aW1lID0gbW92ZV9zL3RoaXMuc3BlZWQ7XHJcbiAgICAgICAgICAgIHZhciBtID0gY2MubW92ZVRvKHRpbWUsIDAsIHRoaXMuY29udGVudGMueSAtIG1vdmVfcyk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50Yy5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0geDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdmFyIG1vdmVfcyA9ICh2YWx1ZSAtIHRoaXMubm93X3ZhbHVlKSAqIHRoaXMubnVtX2hlaWdodDtcclxuICAgICAgICAgICAgdmFyIHRpbWUgPSBtb3ZlX3MgLyB0aGlzLnNwZWVkO1xyXG4gICAgICAgICAgICB2YXIgbSA9IGNjLm1vdmVUbyh0aW1lLCAwLCB0aGlzLmNvbnRlbnRjLnkgKyBtb3ZlX3MpO1xyXG4gICAgICAgICAgICBtLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25Jbk91dCgpKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50Yy5ydW5BY3Rpb24obSk7XHJcbiAgICAgICAgICAgIHRoaXMubm93X3ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgcGxheWluZygpe1xyXG4gICAgICAgIGNjLmxvZyhcImRkZGRkZFwiKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/tonum.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '86b2cgdXpVNu50o9drDB4FE', 'tonum');
// scripts/tonum.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  toNum: function toNum() {
    cc.director.loadScene("num");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdG9udW0uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJ0b051bSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLE1BUEssb0JBT0ssQ0FBRSxDQVBQO0FBUUxDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUNaTCxJQUFBQSxFQUFFLENBQUNNLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixLQUF0QjtBQUNILEdBVkk7QUFXTEMsRUFBQUEsS0FYSyxtQkFXSSxDQUVSLENBYkksQ0FlTDs7QUFmSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQgKCkge30sXHJcbiAgICB0b051bTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIm51bVwiKVxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------
