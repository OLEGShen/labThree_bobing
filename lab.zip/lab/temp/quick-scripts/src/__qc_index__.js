
require('./assets/scripts/count');
require('./assets/scripts/cow');
require('./assets/scripts/gotoanswer');
require('./assets/scripts/guizejs');
require('./assets/scripts/homejs');
require('./assets/scripts/numing');
require('./assets/scripts/rolltwo');
require('./assets/scripts/toanswersss');
require('./assets/scripts/tonum');
require('./assets/scripts/totouzi');
require('./assets/scripts/totouzitwo');
require('./assets/scripts/turnall');
require('./assets/scripts/turnaround');
require('./assets/scripts/turntwo');
